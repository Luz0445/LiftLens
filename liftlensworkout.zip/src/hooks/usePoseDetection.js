import { useEffect, useRef, useState, useCallback } from "react";
import * as tf from "@tensorflow/tfjs";
import * as poseDetection from "@tensorflow-models/pose-detection";

// Keypoint indices for MoveNet
const KP = {
  nose: 0, leftEye: 1, rightEye: 2, leftEar: 3, rightEar: 4,
  leftShoulder: 5, rightShoulder: 6,
  leftElbow: 7, rightElbow: 8,
  leftWrist: 9, rightWrist: 10,
  leftHip: 11, rightHip: 12,
  leftKnee: 13, rightKnee: 14,
  leftAnkle: 15, rightAnkle: 16,
};

const SKELETON_PAIRS = [
  [KP.nose, KP.leftShoulder], [KP.nose, KP.rightShoulder],
  [KP.leftShoulder, KP.rightShoulder],
  [KP.leftShoulder, KP.leftElbow], [KP.leftElbow, KP.leftWrist],
  [KP.rightShoulder, KP.rightElbow], [KP.rightElbow, KP.rightWrist],
  [KP.leftShoulder, KP.leftHip], [KP.rightShoulder, KP.rightHip],
  [KP.leftHip, KP.rightHip],
  [KP.leftHip, KP.leftKnee], [KP.leftKnee, KP.leftAnkle],
  [KP.rightHip, KP.rightKnee], [KP.rightKnee, KP.rightAnkle],
];

function angleBetween(a, b, c) {
  const ab = { x: a.x - b.x, y: a.y - b.y };
  const cb = { x: c.x - b.x, y: c.y - b.y };
  const dot = ab.x * cb.x + ab.y * cb.y;
  const mag = Math.sqrt(ab.x ** 2 + ab.y ** 2) * Math.sqrt(cb.x ** 2 + cb.y ** 2);
  if (mag === 0) return 0;
  return (Math.acos(Math.min(1, Math.max(-1, dot / mag))) * 180) / Math.PI;
}

function getKneeAngle(kps) {
  const lh = kps[KP.leftHip],  lk = kps[KP.leftKnee],  la = kps[KP.leftAnkle];
  const rh = kps[KP.rightHip], rk = kps[KP.rightKnee], ra = kps[KP.rightAnkle];
  const leftOk  = lh?.score > 0.25 && lk?.score > 0.25 && la?.score > 0.25;
  const rightOk = rh?.score > 0.25 && rk?.score > 0.25 && ra?.score > 0.25;
  if (!leftOk && !rightOk) return null;
  const angles = [];
  if (leftOk)  angles.push(angleBetween(lh, lk, la));
  if (rightOk) angles.push(angleBetween(rh, rk, ra));
  return angles.reduce((a, b) => a + b, 0) / angles.length;
}

function getHipAngle(kps) {
  const ls = kps[KP.leftShoulder],  lh = kps[KP.leftHip],  lk = kps[KP.leftKnee];
  const rs = kps[KP.rightShoulder], rh = kps[KP.rightHip], rk = kps[KP.rightKnee];
  const leftOk  = ls?.score > 0.25 && lh?.score > 0.25 && lk?.score > 0.25;
  const rightOk = rs?.score > 0.25 && rh?.score > 0.25 && rk?.score > 0.25;
  if (!leftOk && !rightOk) return null;
  const angles = [];
  if (leftOk)  angles.push(angleBetween(ls, lh, lk));
  if (rightOk) angles.push(angleBetween(rs, rh, rk));
  return angles.reduce((a, b) => a + b, 0) / angles.length;
}

function getElbowAngle(kps) {
  const s = kps[KP.leftShoulder], e = kps[KP.leftElbow], w = kps[KP.leftWrist];
  if (!s || !e || !w || s.score < 0.3 || e.score < 0.3 || w.score < 0.3) return null;
  return angleBetween(s, e, w);
}

function getPoseArea(kps) {
  const valid = kps.filter((kp) => kp.score > 0.3);
  if (valid.length < 3) return 0;
  const xs = valid.map((kp) => kp.x);
  const ys = valid.map((kp) => kp.y);
  return (Math.max(...xs) - Math.min(...xs)) * (Math.max(...ys) - Math.min(...ys));
}

function getClosestPose(poses) {
  if (!poses || poses.length === 0) return null;
  return poses.reduce((best, pose) =>
    getPoseArea(pose.keypoints) > getPoseArea(best.keypoints) ? pose : best, poses[0]);
}

function getPrimaryAngle(kps, category) {
  switch (category) {
    case "squat":
    case "lunge":
      return getKneeAngle(kps);
    case "deadlift":
      return getHipAngle(kps);
    case "bench_press":
    case "overhead_press":
    case "barbell_row":
      return getElbowAngle(kps);
    default:
      return getKneeAngle(kps) ?? getHipAngle(kps);
  }
}

// Preprocess a video frame to normalize brightness/contrast for better tracking in any lighting
function preprocessFrame(video) {
  const offscreen = document.createElement("canvas");
  offscreen.width = video.videoWidth;
  offscreen.height = video.videoHeight;
  const ctx = offscreen.getContext("2d");

  // Draw the raw frame
  ctx.drawImage(video, 0, 0);

  // Sample brightness from a grid of pixels
  const sample = ctx.getImageData(0, 0, offscreen.width, offscreen.height);
  const data = sample.data;
  let total = 0;
  const step = Math.max(1, Math.floor(data.length / 4 / 500)); // sample ~500 pixels
  let count = 0;
  for (let i = 0; i < data.length; i += 4 * step) {
    total += 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    count++;
  }
  const avgBrightness = total / count; // 0–255

  // Target brightness ~130 for good model performance
  const targetBrightness = 130;
  const brightnessShift = targetBrightness - avgBrightness;

  // Apply brightness + contrast boost via CSS filter on a second canvas
  const out = document.createElement("canvas");
  out.width = video.videoWidth;
  out.height = video.videoHeight;
  const octx = out.getContext("2d");

  // Clamp brightness adjustment, boost contrast slightly in dark scenes
  const brightnessPct = Math.round(100 + brightnessShift * 0.55);
  const contrastPct = avgBrightness < 80 ? 140 : avgBrightness < 110 ? 120 : 105;
  octx.filter = `brightness(${brightnessPct}%) contrast(${contrastPct}%)`;
  octx.drawImage(video, 0, 0);
  return out;
}

// Stance width detection: returns null | 'wide' | 'narrow' based on ankle-to-shoulder ratio
function getStanceRatio(kps) {
  const la = kps[KP.leftAnkle], ra = kps[KP.rightAnkle];
  const ls = kps[KP.leftShoulder], rs = kps[KP.rightShoulder];
  if (!la || !ra || !ls || !rs) return null;
  if (la.score < 0.3 || ra.score < 0.3 || ls.score < 0.3 || rs.score < 0.3) return null;
  const ankleWidth = Math.abs(ra.x - la.x);
  const shoulderWidth = Math.abs(rs.x - ls.x);
  if (shoulderWidth < 10) return null;
  const ratio = ankleWidth / shoulderWidth;
  if (ratio > 1.6) return 'wide';
  if (ratio < 0.55) return 'narrow';
  return null;
}

export function usePoseDetection({ videoRef, canvasRef, active, exerciseCategory }) {
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [repCount, setRepCount] = useState(0);
  const [currentAngle, setCurrentAngle] = useState(null);
  const [loadingStatus, setLoadingStatus] = useState("Loading AI model...");
  const [stanceWarning, setStanceWarning] = useState(null); // 'wide' | 'narrow' | null

  const detectorRef = useRef(null);
  const rafRef = useRef(null);
  const repStateRef = useRef("up");
  const lastRepTimeRef = useRef(0);
  const calibrationRef = useRef({ done: false, topAngle: null, bottomAngle: null, phase: "waitTop", samples: [], downThreshold: null, upThreshold: null });
  const repCountRef = useRef(0);
  const angleBufferRef = useRef([]);

  const drawSkeleton = useCallback((ctx, keypoints, width, height) => {
    ctx.clearRect(0, 0, width, height);
    SKELETON_PAIRS.forEach(([i, j]) => {
      const a = keypoints[i], b = keypoints[j];
      if (!a || !b || a.score < 0.3 || b.score < 0.3) return;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.strokeStyle = "rgba(236, 72, 153, 0.85)";
      ctx.lineWidth = 2.5;
      ctx.stroke();
    });
    keypoints.forEach((kp) => {
      if (kp.score < 0.3) return;
      ctx.beginPath();
      ctx.arc(kp.x, kp.y, 5, 0, 2 * Math.PI);
      ctx.fillStyle = kp.score > 0.7 ? "hsl(330, 85%, 75%)" : "hsl(330, 50%, 55%)";
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.6)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
    });
  }, []);

  const processRep = useCallback((angle) => {
    const cal = calibrationRef.current;
    if (!cal.done) {
      cal.samples.push(angle);
      if (cal.samples.length < 5) return;
      const recent = cal.samples.slice(-5);
      const avg = recent.reduce((a, b) => a + b, 0) / recent.length;
      const trend = recent[recent.length - 1] - recent[0];
      if (cal.phase === "waitTop") {
        if (cal.topAngle === null || avg > cal.topAngle) cal.topAngle = avg;
        if (cal.topAngle !== null && trend < -8) cal.phase = "goingDown";
      } else if (cal.phase === "goingDown") {
        if (cal.bottomAngle === null || avg < cal.bottomAngle) cal.bottomAngle = avg;
        if (cal.bottomAngle !== null && trend > 8) cal.phase = "goingUp";
      } else if (cal.phase === "goingUp") {
        const range = cal.topAngle - cal.bottomAngle;
        // More forgiving thresholds: 45% from bottom/top so partial reps still count
        cal.downThreshold = cal.bottomAngle + range * 0.45;
        cal.upThreshold = cal.topAngle - range * 0.45;
        cal.done = true;
        repCountRef.current = 1;
        setRepCount(1);
        repStateRef.current = "up";
      }
      return;
    }
    const { downThreshold, upThreshold } = cal;
    if (repStateRef.current === "up" && angle < downThreshold) {
      repStateRef.current = "down";
    } else if (repStateRef.current === "down" && angle > upThreshold) {
      const now = Date.now();
      if (now - lastRepTimeRef.current >= 500) {
        repStateRef.current = "up";
        repCountRef.current += 1;
        setRepCount(repCountRef.current);
        lastRepTimeRef.current = now;
      } else {
        repStateRef.current = "up";
      }
    }
  }, []);

  useEffect(() => {
    if (!active) return;
    let stopped = false;

    async function loadModel() {
      try {
        setLoadingStatus("Loading TensorFlow...");
        await tf.ready();
        setLoadingStatus("Loading MoveNet model...");
        const detector = await poseDetection.createDetector(
          poseDetection.SupportedModels.MoveNet,
          {
            modelType: poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING,
            enableTracking: true,
          }
        );
        detectorRef.current = detector;
        setIsModelLoaded(true);
        setLoadingStatus("Ready");
      } catch (err) {
        setLoadingStatus("Model load failed: " + err.message);
      }
    }

    async function detectLoop() {
      if (stopped || !detectorRef.current || !videoRef.current || !canvasRef.current) {
        rafRef.current = requestAnimationFrame(detectLoop);
        return;
      }
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video.readyState < 2) {
        rafRef.current = requestAnimationFrame(detectLoop);
        return;
      }
      try {
        const input = preprocessFrame(video);
        const poses = await detectorRef.current.estimatePoses(input, { maxPoses: 3 });
        const closest = getClosestPose(poses);
        if (closest) {
          const scaleX = canvas.width / video.videoWidth;
          const scaleY = canvas.height / video.videoHeight;
          const scaled = closest.keypoints.map((kp) => ({ ...kp, x: kp.x * scaleX, y: kp.y * scaleY }));
          const ctx = canvas.getContext("2d");
          drawSkeleton(ctx, scaled, canvas.width, canvas.height);
          // Stance detection for relevant exercises
          const stanceExercises = ['squat', 'lunge', 'deadlift', 'overhead_press'];
          if (stanceExercises.includes(exerciseCategory)) {
            const ratio = getStanceRatio(closest.keypoints);
            setStanceWarning(ratio);
          } else {
            setStanceWarning(null);
          }

          const rawAngle = getPrimaryAngle(closest.keypoints, exerciseCategory);
          if (rawAngle !== null) {
            // Smooth angle over last 4 frames to reduce jitter
            angleBufferRef.current.push(rawAngle);
            if (angleBufferRef.current.length > 4) angleBufferRef.current.shift();
            const smoothed = angleBufferRef.current.reduce((a, b) => a + b, 0) / angleBufferRef.current.length;
            setCurrentAngle(Math.round(smoothed));
            processRep(smoothed);
          }
        }
      } catch (_) {}
      rafRef.current = requestAnimationFrame(detectLoop);
    }

    loadModel().then(() => { if (!stopped) detectLoop(); });

    return () => {
      stopped = true;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [active, exerciseCategory, drawSkeleton, processRep, videoRef, canvasRef]);

  const resetReps = useCallback(() => {
    repCountRef.current = 0;
    setRepCount(0);
    repStateRef.current = "up";
    calibrationRef.current = { done: false, topAngle: null, bottomAngle: null, phase: "waitTop", samples: [], downThreshold: null, upThreshold: null };
  }, []);

  return { isModelLoaded, repCount, currentAngle, loadingStatus, resetReps, stanceWarning };
}