import { base44 } from "@/api/base44Client";

/**
 * Awards badges and updates streak after a session is saved.
 * Returns { newBadges, streakData }
 */
export async function processBadgesAndStreak({ session, allSessions }) {
  const newBadges = [];
  const today = new Date().toISOString().split("T")[0];

  // --- Streak update ---
  let streakData = null;
  const streaks = await base44.entities.UserStreak.list("-updated_date", 1);
  const existing = streaks[0];

  if (!existing) {
    // First ever session
    streakData = await base44.entities.UserStreak.create({
      streak_count: 1,
      longest_streak: 1,
      last_session_date: today,
      total_sessions: 1,
    });
  } else {
    const last = existing.last_session_date;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];

    let newStreak = existing.streak_count;
    if (last === today) {
      // Already logged today — just increment total
      newStreak = existing.streak_count;
    } else if (last === yesterdayStr) {
      // Consecutive day!
      newStreak = existing.streak_count + 1;
    } else {
      // Streak broken
      newStreak = 1;
    }

    const newTotal = (existing.total_sessions || 0) + 1;
    streakData = await base44.entities.UserStreak.update(existing.id, {
      streak_count: newStreak,
      longest_streak: Math.max(existing.longest_streak || 0, newStreak),
      last_session_date: today,
      total_sessions: newTotal,
    });

    // Streak badges
    const streakMilestones = [
      { count: 3, type: "streak_3", title: "3-Day Streak 🔥", icon: "🔥", desc: "Worked out 3 days in a row" },
      { count: 7, type: "streak_7", title: "Week Warrior", icon: "⚡", desc: "7-day workout streak achieved" },
      { count: 30, type: "streak_30", title: "Iron Discipline", icon: "🏆", desc: "30 days of consecutive training" },
    ];

    for (const m of streakMilestones) {
      if (newStreak === m.count) {
        const already = await base44.entities.Badge.filter({ badge_type: m.type });
        if (already.length === 0) {
          const b = await base44.entities.Badge.create({
            badge_type: m.type,
            title: m.title,
            description: m.desc,
            icon: m.icon,
          });
          newBadges.push(b);
        }
      }
    }
  }

  // --- First session badge ---
  const totalSessions = streakData?.total_sessions || 1;
  if (totalSessions === 1) {
    const b = await base44.entities.Badge.create({
      badge_type: "first_session",
      title: "First Rep",
      description: "Completed your very first tracked session",
      icon: "🌟",
    });
    newBadges.push(b);
  }

  // --- Personal Record badge ---
  const sameExerciseSessions = allSessions.filter(
    (s) => s.exercise === session.exercise && s.id !== session.id
  );
  if (sameExerciseSessions.length > 0) {
    const prevBest = Math.max(...sameExerciseSessions.map((s) => s.form_score));
    if (session.form_score > prevBest) {
      const b = await base44.entities.Badge.create({
        badge_type: "personal_record",
        title: "Personal Record!",
        description: `New form score record for ${session.exercise}: ${session.form_score}`,
        icon: "🎯",
        exercise_name: session.exercise,
        exercise_category: session.exercise_category,
      });
      newBadges.push(b);
    }
  }

  // --- Consistency badge (3 & 5 good sessions in a row for same exercise) ---
  const orderedSame = [...sameExerciseSessions]
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 4);

  const allRecent = [session, ...orderedSame];

  const check3 = allRecent.slice(0, 3).every((s) => s.form_score >= 65);
  const check5 = allRecent.length >= 5 && allRecent.slice(0, 5).every((s) => s.form_score >= 65);

  if (check5) {
    const already = await base44.entities.Badge.filter({
      badge_type: "consistency_5",
      exercise_name: session.exercise,
    });
    if (already.length === 0) {
      const b = await base44.entities.Badge.create({
        badge_type: "consistency_5",
        title: "Elite Consistency",
        description: `5 solid sessions of ${session.exercise} in a row`,
        icon: "💎",
        exercise_name: session.exercise,
        exercise_category: session.exercise_category,
      });
      newBadges.push(b);
    }
  } else if (check3) {
    const already = await base44.entities.Badge.filter({
      badge_type: "consistency_3",
      exercise_name: session.exercise,
    });
    if (already.length === 0) {
      const b = await base44.entities.Badge.create({
        badge_type: "consistency_3",
        title: "On a Roll",
        description: `3 good sessions of ${session.exercise} in a row`,
        icon: "🏅",
        exercise_name: session.exercise,
        exercise_category: session.exercise_category,
      });
      newBadges.push(b);
    }
  }

  // --- High score badges ---
  if (session.form_score >= 90) {
    const already = await base44.entities.Badge.filter({ badge_type: "score_90" });
    if (already.length === 0) {
      const b = await base44.entities.Badge.create({
        badge_type: "score_90",
        title: "Near Perfect",
        description: "Achieved a form score of 90 or higher",
        icon: "✨",
      });
      newBadges.push(b);
    }
  } else if (session.form_score >= 80) {
    const already = await base44.entities.Badge.filter({ badge_type: "score_80" });
    if (already.length === 0) {
      const b = await base44.entities.Badge.create({
        badge_type: "score_80",
        title: "Strong Form",
        description: "Achieved a form score of 80 or higher",
        icon: "💪",
      });
      newBadges.push(b);
    }
  }

  return { newBadges, streakData };
}