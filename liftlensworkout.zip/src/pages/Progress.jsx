import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { TrendingUp, Calendar } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import moment from "moment";
import RecentSessionCard from "../components/RecentSessionCard";

export default function Progress() {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const data = await base44.entities.WorkoutSession.list("-created_date", 50);
      setSessions(data);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const chartData = [...sessions].reverse().map((s) => ({
    date: moment(s.created_date).format("MMM D"),
    score: s.form_score,
    symmetry: s.symmetry_score || 0,
    reps: s.reps_completed,
  }));

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-heading font-bold text-foreground tracking-tight">Progress</h1>
        <p className="text-muted-foreground mt-1">Track your form improvement over time</p>
      </motion.div>

      {sessions.length === 0 ? (
        <div className="bg-card border border-border rounded-xl p-12 text-center">
          <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Complete some sessions to see your progress.</p>
        </div>
      ) : (
        <>
          {/* Form Score Trend */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="font-heading font-semibold text-foreground mb-4">Form Score Trend</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(145 80% 50%)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(145 80% 50%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 15%)" />
                  <XAxis dataKey="date" stroke="hsl(215 15% 50%)" fontSize={11} />
                  <YAxis domain={[0, 100]} stroke="hsl(215 15% 50%)" fontSize={11} />
                  <Tooltip
                    contentStyle={{
                      background: "hsl(220 18% 7%)",
                      border: "1px solid hsl(220 15% 15%)",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                  />
                  <Area type="monotone" dataKey="score" stroke="hsl(145 80% 50%)" fill="url(#scoreGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Symmetry Trend */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="font-heading font-semibold text-foreground mb-4">Symmetry Score</h2>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 15%)" />
                  <XAxis dataKey="date" stroke="hsl(215 15% 50%)" fontSize={11} />
                  <YAxis domain={[0, 100]} stroke="hsl(215 15% 50%)" fontSize={11} />
                  <Tooltip
                    contentStyle={{
                      background: "hsl(220 18% 7%)",
                      border: "1px solid hsl(220 15% 15%)",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                  />
                  <Line type="monotone" dataKey="symmetry" stroke="hsl(200 80% 55%)" strokeWidth={2} dot={{ fill: "hsl(200 80% 55%)" }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* All Sessions */}
          <div>
            <h2 className="font-heading font-semibold text-foreground mb-4">All Sessions</h2>
            <div className="space-y-3">
              {sessions.map((session, i) => (
                <RecentSessionCard key={session.id} session={session} delay={i * 0.03} />
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}