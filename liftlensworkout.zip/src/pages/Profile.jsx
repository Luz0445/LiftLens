import { useState, useEffect } from "react";
import { GOAL_TEMPLATES } from "../lib/goalTemplates";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { User, Save, LogOut, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

export default function Profile() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [deletingAccount, setDeletingAccount] = useState(false);
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    height: "",
    dominant_side: "right",
    fitness_level: "intermediate",
    goals_text: "",
  });
  const { toast } = useToast();

  useEffect(() => {
    async function load() {
      const me = await base44.auth.me();
      setUser(me);
      setFormData({
        height: me.height || "",
        dominant_side: me.dominant_side || "right",
        fitness_level: me.fitness_level || "intermediate",
        goals_text: me.goals_text || "",
      });
      setLoading(false);
    }
    load();
  }, []);

  const saveMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onMutate: async (data) => {
      setUser((u) => ({ ...u, ...data }));
    },
    onSuccess: () => toast({ title: "Profile updated", description: "Your settings have been saved." }),
  });

  async function handleSave() {
    saveMutation.mutate(formData);
  }

  async function handleDeleteAccount() {
    setDeletingAccount(true);
    await base44.entities.WorkoutSession.list("-created_date", 200).then(async (sessions) => {
      for (const s of sessions) await base44.entities.WorkoutSession.delete(s.id);
    });
    base44.auth.logout();
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-2xl">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-heading font-bold text-foreground tracking-tight">Profile</h1>
        <p className="text-muted-foreground mt-1">Customize your training preferences</p>
      </motion.div>

      {/* Avatar + Name */}
      <div className="bg-card border border-border rounded-xl p-6 flex items-center gap-4">
        <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
          <User className="w-7 h-7 text-primary" />
        </div>
        <div>
          <p className="text-lg font-heading font-semibold text-foreground">{user?.full_name || "Athlete"}</p>
          <p className="text-sm text-muted-foreground">{user?.email}</p>
        </div>
      </div>

      {/* Settings */}
      <div className="bg-card border border-border rounded-xl p-6 space-y-5">
        <h2 className="font-heading font-semibold text-foreground">Training Profile</h2>

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Height (cm)</label>
          <Input
            type="number"
            value={formData.height}
            onChange={(e) => setFormData({ ...formData, height: e.target.value })}
            placeholder="e.g., 175"
            className="bg-muted border-border"
          />
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Dominant Side</label>
          <Select value={formData.dominant_side} onValueChange={(v) => setFormData({ ...formData, dominant_side: v })}>
            <SelectTrigger className="bg-muted border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="left">Left</SelectItem>
              <SelectItem value="right">Right</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Fitness Level</label>
          <Select value={formData.fitness_level} onValueChange={(v) => setFormData({ ...formData, fitness_level: v })}>
            <SelectTrigger className="bg-muted border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="beginner">Beginner</SelectItem>
              <SelectItem value="intermediate">Intermediate</SelectItem>
              <SelectItem value="advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Training Goals</label>
          <div className="grid grid-cols-2 gap-2 mt-1">
            {GOAL_TEMPLATES.map((t) => {
              const selected = formData.goals_text === t.title;
              return (
                <button
                  key={t.title}
                  type="button"
                  onClick={() => setFormData({ ...formData, goals_text: selected ? "" : t.title })}
                  className={`text-left p-3 rounded-xl border transition-all ${
                    selected
                      ? "bg-primary/10 border-primary/50 text-primary"
                      : "bg-muted border-border text-muted-foreground hover:border-primary/30 hover:text-foreground"
                  }`}
                >
                  <div className="text-xl mb-1">{t.emoji}</div>
                  <p className="text-xs font-heading font-semibold leading-snug">{t.title}</p>
                  <p className="text-[10px] mt-0.5 leading-snug opacity-70">{t.description}</p>
                </button>
              );
            })}
          </div>
        </div>

        <Button onClick={handleSave} disabled={saveMutation.isPending} className="bg-primary text-primary-foreground hover:bg-primary/90 w-full">
          <Save className="w-4 h-4 mr-2" />
          {saveMutation.isPending ? "Saving..." : "Save Profile"}
        </Button>
      </div>

      {/* Logout */}
      <div className="flex flex-col gap-3">
        <Button
          variant="outline"
          onClick={() => base44.auth.logout()}
          className="border-border text-muted-foreground hover:text-foreground"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sign Out
        </Button>

        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="outline" className="border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive">
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Account
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent className="bg-card border-border">
            <AlertDialogHeader>
              <AlertDialogTitle className="font-heading">Delete Account?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete all your workout sessions and data. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteAccount}
                disabled={deletingAccount}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {deletingAccount ? "Deleting..." : "Yes, Delete Everything"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}