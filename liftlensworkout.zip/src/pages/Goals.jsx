import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import GoalScorePanel from "../components/GoalScorePanel";
import { motion } from "framer-motion";
import { Target, Plus, Trash2, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { GOAL_TEMPLATES } from "../lib/goalTemplates";

const GOAL_TYPES = [
  { value: "form_score", label: "Form Score Target" },
  { value: "consistency", label: "Consistency Rating" },
  { value: "sessions_per_week", label: "Sessions Per Week" },
  { value: "depth", label: "Depth Improvement" },
  { value: "symmetry", label: "Symmetry Score" },
];

export default function Goals() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [newGoal, setNewGoal] = useState({ title: "", goal_type: "form_score", target_value: 90 });

  const { data: goals = [], isLoading: loading } = useQuery({
    queryKey: ["goals"],
    queryFn: () => base44.entities.UserGoal.list("-created_date", 50),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.UserGoal.create(data),
    onMutate: async (data) => {
      await queryClient.cancelQueries({ queryKey: ["goals"] });
      const prev = queryClient.getQueryData(["goals"]);
      queryClient.setQueryData(["goals"], (old) => [{ ...data, id: "temp-" + Date.now() }, ...(old || [])]);
      return { prev };
    },
    onError: (_, __, ctx) => queryClient.setQueryData(["goals"], ctx.prev),
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["goals"] }),
  });

  const completeMutation = useMutation({
    mutationFn: (id) => base44.entities.UserGoal.update(id, { status: "completed" }),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ["goals"] });
      const prev = queryClient.getQueryData(["goals"]);
      queryClient.setQueryData(["goals"], (old) => old.map((g) => g.id === id ? { ...g, status: "completed" } : g));
      return { prev };
    },
    onError: (_, __, ctx) => queryClient.setQueryData(["goals"], ctx.prev),
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["goals"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.UserGoal.delete(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ["goals"] });
      const prev = queryClient.getQueryData(["goals"]);
      queryClient.setQueryData(["goals"], (old) => old.filter((g) => g.id !== id));
      return { prev };
    },
    onError: (_, __, ctx) => queryClient.setQueryData(["goals"], ctx.prev),
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["goals"] }),
  });

  function pickTemplate(template) {
    setSelectedTemplate(template);
    setNewGoal({ title: template.title, goal_type: template.goal_type, target_value: template.target_value });
  }

  async function createGoal() {
    createMutation.mutate({ ...newGoal, status: "active", current_value: 0 });
    setDialogOpen(false);
    setSelectedTemplate(null);
    setNewGoal({ title: "", goal_type: "form_score", target_value: 90 });
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const activeGoals = goals.filter((g) => g.status === "active");
  const completedGoals = goals.filter((g) => g.status === "completed");

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground tracking-tight">Goals</h1>
          <p className="text-muted-foreground mt-1">Set targets and track your progress</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" />
              New Goal
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border max-w-lg">
            <DialogHeader>
              <DialogTitle className="font-heading">
                {selectedTemplate ? "Customize Goal" : "Choose a Goal"}
              </DialogTitle>
            </DialogHeader>

            {!selectedTemplate ? (
              <div className="grid grid-cols-2 gap-3 mt-4">
                {GOAL_TEMPLATES.map((t) => (
                  <button
                    key={t.title}
                    onClick={() => pickTemplate(t)}
                    className="text-left p-4 bg-muted hover:bg-secondary border border-border hover:border-primary/40 rounded-xl transition-all group"
                  >
                    <div className="text-2xl mb-2">{t.emoji}</div>
                    <p className="text-sm font-heading font-semibold text-foreground">{t.title}</p>
                    <p className="text-[11px] text-muted-foreground mt-1 leading-snug">{t.description}</p>
                  </button>
                ))}
              </div>
            ) : (
              <div className="space-y-4 mt-4">
                <button onClick={() => setSelectedTemplate(null)} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1">← Back to templates</button>
                <div className="flex items-center gap-3 bg-muted rounded-xl p-3">
                  <span className="text-3xl">{selectedTemplate.emoji}</span>
                  <div>
                    <p className="text-sm font-heading font-semibold text-foreground">{selectedTemplate.title}</p>
                    <p className="text-[11px] text-muted-foreground">{selectedTemplate.description}</p>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Goal Title</label>
                  <Input
                    value={newGoal.title}
                    onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                    placeholder="Customize your goal title"
                    className="bg-muted border-border"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">{selectedTemplate.placeholder}</label>
                  <Input
                    type="number"
                    value={newGoal.target_value}
                    onChange={(e) => setNewGoal({ ...newGoal, target_value: Number(e.target.value) })}
                    className="bg-muted border-border"
                  />
                </div>
                <Button onClick={createGoal} disabled={!newGoal.title} className="w-full bg-primary text-primary-foreground">
                  Create Goal
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </motion.div>

      {/* Live Progress */}
      <GoalScorePanel />

      {/* Active Goals */}
      {activeGoals.length === 0 && completedGoals.length === 0 ? (
        <div className="bg-card border border-border rounded-xl p-12 text-center">
          <Target className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No goals yet. Create your first goal!</p>
        </div>
      ) : (
        <>
          {activeGoals.length > 0 && (
            <div>
              <h2 className="font-heading font-semibold text-foreground mb-4">Active Goals</h2>
              <div className="space-y-3">
                {activeGoals.map((goal, i) => (
                  <GoalCard key={goal.id} goal={goal} index={i} onComplete={(id) => completeMutation.mutate(id)} onDelete={(id) => deleteMutation.mutate(id)} />
                ))}
              </div>
            </div>
          )}
          {completedGoals.length > 0 && (
            <div>
              <h2 className="font-heading font-semibold text-foreground mb-4 text-muted-foreground">Completed</h2>
              <div className="space-y-3 opacity-60">
                {completedGoals.map((goal, i) => (
                  <GoalCard key={goal.id} goal={goal} index={i} onDelete={(id) => deleteMutation.mutate(id)} completed />
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function GoalCard({ goal, index, onComplete, onDelete, completed }) {
  const progress = goal.target_value ? Math.min(((goal.current_value || 0) / goal.target_value) * 100, 100) : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="bg-card border border-border rounded-xl p-4"
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-foreground">{goal.title}</p>
          <p className="text-xs text-muted-foreground mt-1 capitalize">
            {GOAL_TYPES.find((t) => t.value === goal.goal_type)?.label || goal.goal_type}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {!completed && onComplete && (
            <button onClick={() => onComplete(goal.id)} className="p-1.5 hover:bg-primary/10 rounded-lg transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center">
              <Check className="w-4 h-4 text-primary" />
            </button>
          )}
          <button onClick={() => onDelete(goal.id)} className="p-1.5 hover:bg-destructive/10 rounded-lg transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center">
            <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
          </button>
        </div>
      </div>
      <div className="mt-3">
        <div className="flex justify-between text-xs text-muted-foreground mb-1">
          <span>{goal.current_value || 0}</span>
          <span>{goal.target_value}</span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all ${completed ? "bg-primary/50" : "bg-primary"}`}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </motion.div>
  );
}