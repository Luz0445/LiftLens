import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { ArrowLeft, Clock, Dumbbell, TrendingUp, TrendingDown, Zap, BarChart3, User } from "lucide-react";
import moment from "moment";
import FormScoreRing from "../components/FormScoreRing";
import CoachingCard from "../components/CoachingCard";
import RepTimeline from "../components/RepTimeline";
import InjuryRiskCard from "../components/InjuryRiskCard";
import SkeletonOverlay from "../components/SkeletonOverlay";
import SessionJointAngles from "../components/SessionJointAngles";
import ProJointComparison from "../components/ProJointComparison";

export default function SessionDetail() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  const urlParams = new URLSearchParams(window.location.search);
  const sessionId = urlParams.get("id");

  useEffect(() => {
    async function load() {
      if (!sessionId) { setLoading(false); return; }
      const sessions = await base44.entities.WorkoutSession.filter({ id: sessionId });
      if (sessions.length > 0) setSession(sessions[0]);
      setLoading(false);
    }
    load();
  }, [sessionId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!session) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">Session not found.</p>
        <Link to="/" className="text-primary text-sm mt-2 inline-block">Back to Dashboard</Link>
      </div>
    );
  }

  const jointStatus = {};
  if (session.joint_angles) {
    Object.entries(session.joint_angles).forEach(([key, value]) => {
      const simpleName = key.replace("_left", "").replace("_right", "");
      const side = key.includes("left") ? "left" : "right";
      const jointName = `${simpleName}_${side}`;
      jointStatus[jointName] = value > 90 ? "good" : value > 70 ? "warning" : "bad";
    });
  }

  return (
    <div className="space-y-6">
      <Link to="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="w-4 h-4" />
        Back to Dashboard
      </Link>

      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-heading font-bold text-foreground">{session.exercise}</h1>
            {session.user_name && (
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                <User className="w-3 h-3" />{session.user_name}
              </p>
            )}
            <p className="text-muted-foreground text-sm mt-1 flex items-center gap-3">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {moment(session.created_date).format("MMM D, YYYY · h:mm A")}
              </span>
              {session.duration_seconds && (
                <span>{Math.floor(session.duration_seconds / 60)}m {session.duration_seconds % 60}s</span>
              )}
            </p>
          </div>
          <div className={`text-xs px-3 py-1.5 rounded-full font-medium capitalize ${
            session.consistency_rating === "excellent" ? "bg-primary/10 text-primary" :
            session.consistency_rating === "good" ? "bg-primary/10 text-primary" :
            session.consistency_rating === "fair" ? "bg-accent/10 text-accent" :
            "bg-destructive/10 text-destructive"
          }`}>
            {session.consistency_rating} consistency
          </div>
        </div>
      </motion.div>

      {/* Score + Skeleton */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="bg-card border border-border rounded-xl p-6 flex flex-col items-center justify-center gap-4">
          <FormScoreRing score={session.form_score} size={160} strokeWidth={10} />
          <div className="text-center">
            <p className="text-sm font-medium text-foreground">{session.reps_completed} reps · {session.sets_completed || 1} set</p>
            <p className="text-xs text-muted-foreground mt-1">{session.primary_focus_area}</p>
          </div>
        </div>

        <SkeletonOverlay jointStatus={jointStatus} className="lg:col-span-1" />

        <div className="space-y-4">
          {/* Improvements */}
          <div className="bg-card border border-border rounded-xl p-4 space-y-3">
            <h3 className="text-sm font-heading font-semibold text-foreground">Progress vs Last Session</h3>
            {session.depth_improvement !== undefined && (
              <div className="flex items-center gap-2">
                {session.depth_improvement >= 0 ? (
                  <TrendingUp className="w-4 h-4 text-primary" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-destructive" />
                )}
                <span className="text-sm text-secondary-foreground">
                  Depth {session.depth_improvement >= 0 ? "improved" : "decreased"} {Math.abs(session.depth_improvement)}%
                </span>
              </div>
            )}
            {session.alignment_improvement !== undefined && (
              <div className="flex items-center gap-2">
                {session.alignment_improvement >= 0 ? (
                  <TrendingUp className="w-4 h-4 text-primary" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-destructive" />
                )}
                <span className="text-sm text-secondary-foreground">
                  Alignment {session.alignment_improvement >= 0 ? "more" : "less"} consistent
                </span>
              </div>
            )}
            {session.symmetry_score && (
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-accent" />
                <span className="text-sm text-secondary-foreground">
                  Symmetry score: {session.symmetry_score}%
                </span>
              </div>
            )}
          </div>

          {/* Fatigue */}
          {session.fatigue_onset_rep && (
            <div className="bg-accent/5 border border-accent/20 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-1">
                <BarChart3 className="w-4 h-4 text-accent" />
                <span className="text-sm font-medium text-accent">Fatigue Detected</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Form degraded after rep {session.fatigue_onset_rep}. Consider lowering weight or taking longer rest.
              </p>
            </div>
          )}

          {/* Strengths */}
          {session.strengths?.length > 0 && (
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="text-sm font-heading font-semibold text-foreground mb-2">Strengths</h3>
              {session.strengths.map((s, i) => (
                <p key={i} className="text-xs text-primary flex items-center gap-2 py-1">
                  <span className="w-1 h-1 rounded-full bg-primary" />
                  {s}
                </p>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Coaching + Reps */}
      <div className="grid lg:grid-cols-2 gap-6">
        <CoachingCard cues={session.coaching_cues || []} />
        <RepTimeline repData={session.rep_data || []} />
      </div>

      {/* Pro Comparison */}
      {session.joint_angles && (
        <ProJointComparison userAngles={session.joint_angles} exerciseCategory={session.exercise_category} />
      )}

      {/* Joint Angles */}
      {session.joint_angles && <SessionJointAngles angles={session.joint_angles} />}

      {/* Injury Risks */}
      <InjuryRiskCard risks={session.injury_risks || []} />
    </div>
  );
}