import { useState, useEffect, useRef, useCallback } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Dumbbell, TrendingUp, Zap, ArrowRight, Calendar, Flame, Target } from "lucide-react";
import FormScoreRing from "../components/FormScoreRing";
import StatCard from "../components/StatCard";
import RecentSessionCard from "../components/RecentSessionCard";
import BadgesSection from "../components/BadgesSection";

export default function Dashboard() {
  const [sessions, setSessions] = useState([]);
  const [goals, setGoals] = useState([]);
  const [streak, setStreak] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const queryClient = useQueryClient();
  const touchStartY = useRef(null);
  const containerRef = useRef(null);

  const load = useCallback(async () => {
    const [s, g, streaks] = await Promise.all([
      base44.entities.WorkoutSession.list("-created_date", 10),
      base44.entities.UserGoal.filter({ status: "active" }, "-created_date", 5),
      base44.entities.UserStreak.list("-updated_date", 1),
    ]);
    setSessions(s);
    setGoals(g);
    setStreak(streaks[0]?.streak_count || 0);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleTouchStart = useCallback((e) => {
    if (containerRef.current?.scrollTop === 0) {
      touchStartY.current = e.touches[0].clientY;
    }
  }, []);

  const handleTouchEnd = useCallback(async (e) => {
    if (touchStartY.current === null) return;
    const dy = e.changedTouches[0].clientY - touchStartY.current;
    touchStartY.current = null;
    if (dy > 60) {
      setRefreshing(true);
      queryClient.invalidateQueries();
      await load();
      setRefreshing(false);
    }
  }, [load, queryClient]);

  const avgScore = sessions.length
    ? Math.round(sessions.reduce((a, s) => a + (s.form_score || 0), 0) / sessions.length)
    : 0;
  const totalReps = sessions.reduce((a, s) => a + (s.reps_completed || 0), 0);
  const thisWeek = sessions.filter((s) => {
    const d = new Date(s.created_date);
    const now = new Date();
    const diff = (now - d) / (1000 * 60 * 60 * 24);
    return diff <= 7;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="space-y-8"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {refreshing && (
        <div className="flex justify-center pt-2">
          <div className="w-5 h-5 border-2 border-muted border-t-primary rounded-full animate-spin" />
        </div>
      )}
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl lg:text-4xl font-heading font-bold text-foreground tracking-tight">
          Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">Your form analysis at a glance</p>
      </motion.div>

      {/* Quick Action */}
      <Link
        to="/record"
        className="block bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-2xl p-6 hover:border-primary/40 transition-all group"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center group-hover:animate-pulse-glow transition-all">
              <Dumbbell className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h2 className="font-heading font-semibold text-foreground text-lg">Start New Session</h2>
              <p className="text-sm text-muted-foreground">Record and analyze your form</p>
            </div>
          </div>
          <ArrowRight className="w-5 h-5 text-primary group-hover:translate-x-1 transition-transform" />
        </div>
      </Link>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Flame} label="Avg Form Score" value={avgScore || "—"} delay={0} trend={sessions.length > 1 ? 5 : undefined} />
        <StatCard icon={Zap} label="Total Reps" value={totalReps} delay={0.05} />
        <StatCard icon={Calendar} label="Day Streak" value={streak > 0 ? `${streak} 🔥` : "—"} delay={0.1} />
        <StatCard icon={Target} label="Active Goals" value={goals.length} delay={0.15} />
      </div>

      {/* Main Content */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Form Score Overview */}
        <div className="bg-card border border-border rounded-xl p-6 flex flex-col items-center justify-center">
          <FormScoreRing score={avgScore || 0} size={140} />
          <p className="text-sm text-muted-foreground mt-4">Average across {sessions.length} sessions</p>
        </div>

        {/* Recent Sessions */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-heading font-semibold text-foreground text-lg">Recent Sessions</h2>
            <Link to="/progress" className="text-xs text-primary hover:underline flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          {sessions.length === 0 ? (
            <div className="bg-card border border-border rounded-xl p-8 text-center">
              <Dumbbell className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">No sessions yet. Start your first workout!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {sessions.slice(0, 5).map((session, i) => (
                <RecentSessionCard key={session.id} session={session} delay={i * 0.05} />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Badges & Streak */}
      <BadgesSection streakCount={streak} />

      {/* Goals Preview */}
      {goals.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-heading font-semibold text-foreground text-lg">Active Goals</h2>
            <Link to="/goals" className="text-xs text-primary hover:underline flex items-center gap-1">
              Manage <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {goals.map((goal) => (
              <div key={goal.id} className="bg-card border border-border rounded-xl p-4">
                <p className="text-sm font-medium text-foreground">{goal.title}</p>
                <div className="mt-3 w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all"
                    style={{ width: `${Math.min(((goal.current_value || 0) / goal.target_value) * 100, 100)}%` }}
                  />
                </div>
                <p className="text-[11px] text-muted-foreground mt-2">
                  {goal.current_value || 0} / {goal.target_value}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}