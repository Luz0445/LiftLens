import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, ChevronRight, ChevronLeft, Dumbbell, Info, ListChecks, Layers } from "lucide-react";
import ExerciseSelector from "../components/ExerciseSelector";
import CameraSetup from "../components/CameraSetup";
import RecordingView from "../components/RecordingView";
import RoutinePanel from "../components/RoutinePanel";
import GoalScorePanel from "../components/GoalScorePanel";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

const STEPS = ["select", "setup", "record"];

export default function Record() {
  const [step, setStep] = useState(0);
  const [selectedExercise, setSelectedExercise] = useState(null);
  const [activeTab, setActiveTab] = useState("exercises"); // "exercises" | "routines"
  const navigate = useNavigate();

  const { data: allExercises = [] } = useQuery({
    queryKey: ["exercises"],
    queryFn: () => base44.entities.Exercise.list("name", 50),
  });

  function handleRoutineStart(routine) {
    if (!routine.exercises?.length) return;
    const first = routine.exercises[0];
    const exerciseObj = allExercises.find((e) => e.id === first.exercise_id) ||
      { id: first.exercise_id, name: first.exercise_name, category: first.exercise_category };
    setSelectedExercise(exerciseObj);
    setStep(1);
  }

  const handleExerciseSelect = (exercise) => {
    setSelectedExercise(exercise);
    setStep(1);
  };

  const handleRecordComplete = (sessionId) => {
    navigate(`/session?id=${sessionId}`);
  };

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-heading font-bold text-foreground tracking-tight">Record Session</h1>
        <p className="text-muted-foreground mt-1">Analyze your form in real-time</p>
      </motion.div>

      {/* Goal Scores */}
      {step === 0 && <GoalScorePanel />}

      {/* Progress Steps */}
      <div className="flex items-center gap-2">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-all ${
              i <= step ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            }`}>
              {i + 1}
            </div>
            <span className={`text-xs font-medium hidden sm:inline ${
              i <= step ? "text-foreground" : "text-muted-foreground"
            }`}>
              {s === "select" ? "Exercise" : s === "setup" ? "Camera" : "Record"}
            </span>
            {i < STEPS.length - 1 && (
              <div className={`w-8 h-px ${i < step ? "bg-primary" : "bg-border"}`} />
            )}
          </div>
        ))}
      </div>

      {/* Step Content */}
      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="select" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <div className="flex gap-2 mb-4 bg-muted rounded-xl p-1">
              <button
                onClick={() => setActiveTab("exercises")}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === "exercises" ? "bg-card text-foreground shadow" : "text-muted-foreground"
                }`}
              >
                <Dumbbell className="w-4 h-4" /> Exercises
              </button>
              <button
                onClick={() => setActiveTab("routines")}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === "routines" ? "bg-card text-foreground shadow" : "text-muted-foreground"
                }`}
              >
                <Layers className="w-4 h-4" /> Routines
              </button>
            </div>
            {activeTab === "exercises" ? (
              <ExerciseSelector onSelect={handleExerciseSelect} />
            ) : (
              <RoutinePanel exercises={allExercises} onStartRoutine={handleRoutineStart} />
            )}
          </motion.div>
        )}
        {step === 1 && (
          <motion.div key="setup" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <CameraSetup exercise={selectedExercise} onReady={() => setStep(2)} onBack={() => setStep(0)} />
          </motion.div>
        )}
        {step === 2 && (
          <motion.div key="record" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <RecordingView exercise={selectedExercise} onComplete={handleRecordComplete} onBack={() => setStep(1)} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}