import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { GitCompare, ArrowRight } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import FormScoreRing from "../components/FormScoreRing";
import RepTimeline from "../components/RepTimeline";
import moment from "moment";

export default function Compare() {
  const [sessions, setSessions] = useState([]);
  const [leftId, setLeftId] = useState("");
  const [rightId, setRightId] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const data = await base44.entities.WorkoutSession.list("-created_date", 50);
      setSessions(data);
      if (data.length >= 2) {
        setLeftId(data[data.length - 1].id);
        setRightId(data[0].id);
      }
      setLoading(false);
    }
    load();
  }, []);

  const leftSession = sessions.find((s) => s.id === leftId);
  const rightSession = sessions.find((s) => s.id === rightId);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-heading font-bold text-foreground tracking-tight">Compare Sessions</h1>
        <p className="text-muted-foreground mt-1">Side-by-side form comparison</p>
      </motion.div>

      {sessions.length < 2 ? (
        <div className="bg-card border border-border rounded-xl p-12 text-center">
          <GitCompare className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Complete at least 2 sessions to compare.</p>
        </div>
      ) : (
        <>
          {/* Selectors */}
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px]">
              <label className="text-xs text-muted-foreground mb-1 block">Session A</label>
              <Select value={leftId} onValueChange={setLeftId}>
                <SelectTrigger className="bg-card border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sessions.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.exercise} — {moment(s.created_date).format("MMM D")} (Score: {s.form_score})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <ArrowRight className="w-5 h-5 text-muted-foreground mt-4 hidden sm:block" />
            <div className="flex-1 min-w-[200px]">
              <label className="text-xs text-muted-foreground mb-1 block">Session B</label>
              <Select value={rightId} onValueChange={setRightId}>
                <SelectTrigger className="bg-card border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sessions.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.exercise} — {moment(s.created_date).format("MMM D")} (Score: {s.form_score})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Comparison */}
          {leftSession && rightSession && (
            <div className="space-y-6">
              {/* Score Comparison */}
              <div className="grid grid-cols-2 gap-6">
                <ComparisonPanel session={leftSession} label="Session A" />
                <ComparisonPanel session={rightSession} label="Session B" />
              </div>

              {/* Rep Timeline Comparison */}
              <div className="grid lg:grid-cols-2 gap-6">
                <div>
                  <p className="text-xs text-muted-foreground mb-2">Session A Reps</p>
                  <RepTimeline repData={leftSession.rep_data || []} />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-2">Session B Reps</p>
                  <RepTimeline repData={rightSession.rep_data || []} />
                </div>
              </div>

              {/* Delta Summary */}
              <div className="bg-card border border-border rounded-xl p-5">
                <h3 className="font-heading font-semibold text-foreground mb-4">Comparison Summary</h3>
                <div className="grid sm:grid-cols-3 gap-4">
                  <DeltaItem
                    label="Form Score"
                    valueA={leftSession.form_score}
                    valueB={rightSession.form_score}
                  />
                  <DeltaItem
                    label="Reps"
                    valueA={leftSession.reps_completed}
                    valueB={rightSession.reps_completed}
                  />
                  <DeltaItem
                    label="Symmetry"
                    valueA={leftSession.symmetry_score}
                    valueB={rightSession.symmetry_score}
                    suffix="%"
                  />
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ComparisonPanel({ session, label }) {
  return (
    <div className="bg-card border border-border rounded-xl p-5 flex flex-col items-center">
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <p className="text-sm font-medium text-foreground mb-3">{session.exercise}</p>
      <FormScoreRing score={session.form_score} size={100} strokeWidth={6} label="" />
      <p className="text-xs text-muted-foreground mt-3">{moment(session.created_date).format("MMM D, YYYY")}</p>
      <p className="text-xs text-muted-foreground">{session.reps_completed} reps • {session.consistency_rating}</p>
    </div>
  );
}

function DeltaItem({ label, valueA, valueB, suffix = "" }) {
  const delta = (valueB || 0) - (valueA || 0);
  return (
    <div className="bg-muted/50 rounded-lg p-3 text-center">
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <p className="text-lg font-heading font-bold text-foreground">
        {valueA || "—"}{suffix} → {valueB || "—"}{suffix}
      </p>
      {delta !== 0 && (
        <p className={`text-xs font-medium ${delta > 0 ? "text-primary" : "text-destructive"}`}>
          {delta > 0 ? "+" : ""}{delta}{suffix}
        </p>
      )}
    </div>
  );
}