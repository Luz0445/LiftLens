import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Trophy, Flame } from "lucide-react";
import moment from "moment";

const BADGE_DESCRIPTIONS = {
  streak_3: "Worked out 3 days in a row",
  streak_7: "7-day workout streak",
  streak_30: "30 days of consecutive training",
  consistency_3: "3 good sessions of an exercise in a row",
  consistency_5: "5 solid sessions of an exercise in a row",
  personal_record: "Beat your previous best form score",
  first_session: "Completed your first tracked session",
  score_80: "Achieved a form score of 80 or higher",
  score_90: "Achieved a form score of 90 or higher",
};

export default function Badges() {
  const [badges, setBadges] = useState([]);
  const [streak, setStreak] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.Badge.list("-created_date", 100),
      base44.entities.UserStreak.list("-updated_date", 1),
    ]).then(([b, s]) => {
      setBadges(b);
      setStreak(s[0] || null);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl lg:text-4xl font-heading font-bold text-foreground tracking-tight">Achievements</h1>
        <p className="text-muted-foreground mt-1">Badges and streaks you've earned</p>
      </motion.div>

      {/* Streak Card */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-orange-500/10 to-primary/10 border border-orange-500/20 rounded-2xl p-6 flex items-center gap-6"
      >
        <div className="text-5xl">🔥</div>
        <div className="flex-1">
          <p className="text-xl font-heading font-bold text-foreground">
            {streak?.streak_count > 0 ? `${streak.streak_count}-Day Streak` : "No active streak"}
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            Longest: {streak?.longest_streak || 0} days · Total sessions: {streak?.total_sessions || 0}
          </p>
        </div>
        <div className="text-4xl font-heading font-black text-orange-400">{streak?.streak_count || 0}</div>
      </motion.div>

      {/* Badges Grid */}
      {badges.length === 0 ? (
        <div className="bg-card border border-border rounded-2xl p-12 text-center">
          <Trophy className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="font-heading font-semibold text-foreground">No badges yet</p>
          <p className="text-sm text-muted-foreground mt-2">Complete sessions to earn your first achievement</p>
        </div>
      ) : (
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-5 h-5 text-primary" />
            <h2 className="font-heading font-semibold text-foreground text-lg">Badges Earned</h2>
            <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{badges.length}</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {badges.map((badge, i) => (
              <motion.div
                key={badge.id}
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.04 }}
                className="bg-card border border-border rounded-2xl p-5 flex flex-col items-center text-center gap-2 hover:border-primary/30 transition-colors"
              >
                <span className="text-4xl">{badge.icon}</span>
                <p className="text-sm font-heading font-bold text-foreground leading-tight">{badge.title}</p>
                <p className="text-[11px] text-muted-foreground leading-tight">{badge.description || BADGE_DESCRIPTIONS[badge.badge_type]}</p>
                {badge.exercise_name && (
                  <span className="text-[10px] text-primary bg-primary/10 px-2 py-0.5 rounded-full">{badge.exercise_name}</span>
                )}
                <p className="text-[10px] text-muted-foreground/60 mt-auto">{moment(badge.created_date).fromNow()}</p>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}