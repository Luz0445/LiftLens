import { MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function CoachingCard({ cues = [] }) {
  if (!cues.length) return null;

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
          <MessageCircle className="w-4 h-4 text-primary" />
        </div>
        <h3 className="font-heading font-semibold text-foreground">Coaching Cues</h3>
      </div>
      <div className="space-y-3">
        {cues.map((cue, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="flex items-start gap-3 pl-3 border-l-2 border-primary/30"
          >
            <p className="text-sm text-secondary-foreground leading-relaxed">"{cue}"</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}