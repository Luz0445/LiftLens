import { Outlet, Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Dumbbell, TrendingUp, GitCompare, User, Target, Menu, X, Trophy } from "lucide-react";

function LiftLensLogo({ size = 36 }) {
  const s = size;
  return (
    <svg width={s} height={s} viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Corner brackets */}
      <path d="M6 20 L6 6 L20 6" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <path d="M60 6 L74 6 L74 20" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <path d="M6 60 L6 74 L20 74" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <path d="M60 74 L74 74 L74 60" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      {/* Head */}
      <circle cx="40" cy="16" r="5" fill="hsl(330,85%,62%)"/>
      {/* Torso */}
      <line x1="40" y1="21" x2="40" y2="44" stroke="white" strokeWidth="3" strokeLinecap="round"/>
      {/* Arms */}
      <line x1="40" y1="28" x2="28" y2="36" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
      <line x1="40" y1="28" x2="52" y2="36" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
      {/* Hips */}
      <line x1="33" y1="44" x2="47" y2="44" stroke="hsl(330,85%,62%)" strokeWidth="3" strokeLinecap="round"/>
      {/* Legs */}
      <line x1="33" y1="44" x2="30" y2="60" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
      <line x1="47" y1="44" x2="50" y2="60" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
      {/* Feet */}
      <line x1="28" y1="60" x2="33" y2="60" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
      <line x1="48" y1="60" x2="53" y2="60" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
      {/* Joint dots */}
      <circle cx="28" cy="36" r="2" fill="hsl(330,85%,62%)"/>
      <circle cx="52" cy="36" r="2" fill="hsl(330,85%,62%)"/>
      <circle cx="30" cy="60" r="2" fill="hsl(330,85%,62%)"/>
      <circle cx="50" cy="60" r="2" fill="hsl(330,85%,62%)"/>
    </svg>
  );
}
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import BottomNav from "./BottomNav";

const navItems = [
  { path: "/", icon: LayoutDashboard, label: "Dashboard" },
  { path: "/record", icon: Dumbbell, label: "Record" },
  { path: "/progress", icon: TrendingUp, label: "Progress" },
  { path: "/compare", icon: GitCompare, label: "Compare" },
  { path: "/goals", icon: Target, label: "Goals" },
  { path: "/badges", icon: Trophy, label: "Badges" },
  { path: "/profile", icon: User, label: "Profile" },
];

export default function Layout() {
  useTheme();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background font-body flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-[240px] border-r border-border bg-card/50 backdrop-blur-xl fixed h-full z-30">
        <div className="p-6 border-b border-border">
          <Link to="/" className="flex items-center gap-2">
            <LiftLensLogo size={36} />
            <div className="leading-none">
              <span className="font-heading font-bold text-xl tracking-tight"><span className="text-primary italic">Lift</span><span className="text-foreground">Lens</span></span>
              <p className="text-[9px] text-muted-foreground tracking-widest">Train Smarter <span className="text-primary">Move Better</span></p>
            </div>
          </Link>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                }`}
              >
                <item.icon className="w-[18px] h-[18px]" />
                {item.label}
                {isActive && (
                  <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary" />
                )}
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-border">
          <div className="px-4 py-3 rounded-lg bg-primary/5 border border-primary/10">
            <p className="text-xs text-primary font-medium">LiftLens Pro</p>
            <p className="text-[11px] text-muted-foreground mt-1">AI-powered form analysis</p>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div
        className="lg:hidden fixed top-0 left-0 right-0 bg-card/80 backdrop-blur-xl border-b border-border z-30 flex items-center justify-between px-4"
        style={{ paddingTop: "env(safe-area-inset-top)", height: "calc(env(safe-area-inset-top) + 4rem)" }}
      >
        <Link to="/" className="flex items-center gap-2">
          <LiftLensLogo size={28} />
          <span className="font-heading font-bold text-lg tracking-tight"><span className="text-primary italic">Lift</span><span className="text-foreground">Lens</span></span>
        </Link>
        <button onClick={() => setMobileOpen(!mobileOpen)} className="p-2 text-foreground">
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Bottom Nav */}
      <BottomNav />

      {/* Mobile Nav Overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="lg:hidden fixed top-16 left-0 right-0 bg-card/95 backdrop-blur-xl border-b border-border z-20 p-4"
          >
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                    isActive ? "bg-primary/10 text-primary" : "text-muted-foreground"
                  }`}
                >
                  <item.icon className="w-[18px] h-[18px]" />
                  {item.label}
                </Link>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 lg:ml-[240px] pt-16 lg:pt-0 pb-20 lg:pb-0">
        <div className="max-w-6xl mx-auto p-4 lg:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.18, ease: "easeOut" }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}