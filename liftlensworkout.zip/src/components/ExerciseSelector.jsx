import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Search, Dumbbell } from "lucide-react";
import { Input } from "@/components/ui/input";

const EXERCISE_ICONS = {
  squat: "🏋️",
  deadlift: "💪",
  bench_press: "🔥",
  overhead_press: "⬆️",
  barbell_row: "🚣",
  lunge: "🦵",
  push_up: "🤸",
  other: "⚡",
};

export default function ExerciseSelector({ onSelect }) {
  const [exercises, setExercises] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const data = await base44.entities.Exercise.list("name", 50);
      setExercises(data);
      setLoading(false);
    }
    load();
  }, []);

  const filtered = exercises.filter((e) =>
    e.name.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="w-6 h-6 border-3 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search exercises..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10 bg-card border-border"
        />
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-12">
          <Dumbbell className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No exercises found. Add exercises from the admin panel.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-3">
          {filtered.map((exercise, i) => (
            <motion.button
              key={exercise.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              onClick={() => onSelect(exercise)}
              className="flex items-center gap-4 bg-card border border-border rounded-xl p-4 hover:border-primary/40 transition-all text-left group"
            >
              <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center text-xl">
                {EXERCISE_ICONS[exercise.category] || "⚡"}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                  {exercise.name}
                </p>
                <p className="text-xs text-muted-foreground capitalize mt-0.5">
                  {exercise.difficulty || "All levels"} • {(exercise.muscle_groups || []).join(", ") || exercise.category}
                </p>
              </div>
            </motion.button>
          ))}
        </div>
      )}
    </div>
  );
}