import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronRight, Clock } from "lucide-react";
import moment from "moment";

export default function RecentSessionCard({ session, delay = 0 }) {
  const getScoreColor = (score) => {
    if (score >= 80) return "text-primary";
    if (score >= 60) return "text-accent";
    return "text-destructive";
  };

  const getScoreBg = (score) => {
    if (score >= 80) return "bg-primary/10";
    if (score >= 60) return "bg-accent/10";
    return "bg-destructive/10";
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay }}
    >
      <Link
        to={`/session?id=${session.id}`}
        className="flex items-center gap-4 bg-card border border-border rounded-xl p-4 hover:border-primary/30 transition-all group"
      >
        <div className={`w-12 h-12 rounded-xl ${getScoreBg(session.form_score)} flex items-center justify-center flex-shrink-0`}>
          <span className={`text-lg font-heading font-bold ${getScoreColor(session.form_score)}`}>
            {session.form_score}
          </span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground truncate">{session.exercise}</p>
          <div className="flex items-center gap-3 mt-1">
            <span className="text-xs text-muted-foreground">{session.reps_completed} reps</span>
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {moment(session.created_date).fromNow()}
            </span>
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
      </Link>
    </motion.div>
  );
}