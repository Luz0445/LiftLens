import { motion } from "framer-motion";

// Ideal professional angles per exercise category
export const PRO_ANGLES = {
  squat:           { knee: 90,  hip: 80,  shoulder: 170, ankle: 65 },
  lunge:           { knee: 90,  hip: 90,  shoulder: 170, ankle: 70 },
  deadlift:        { knee: 130, hip: 45,  shoulder: 160, ankle: 70 },
  bench_press:     { knee: 90,  hip: 90,  shoulder: 75,  ankle: 90 },
  overhead_press:  { knee: 170, hip: 170, shoulder: 90,  ankle: 80 },
  barbell_row:     { knee: 150, hip: 60,  shoulder: 90,  ankle: 80 },
  push_up:         { knee: 170, hip: 170, shoulder: 90,  ankle: 90 },
  other:           { knee: 90,  hip: 90,  shoulder: 90,  ankle: 80 },
};

function delta(user, pro) {
  if (user == null || pro == null) return null;
  return Math.round(user - pro);
}

function DeltaBadge({ d }) {
  if (d === null) return <span className="text-muted-foreground text-xs">—</span>;
  const abs = Math.abs(d);
  const color = abs <= 5 ? "text-green-400" : abs <= 15 ? "text-yellow-400" : "text-red-400";
  return <span className={`text-xs font-semibold ${color}`}>{d > 0 ? "+" : ""}{d}°</span>;
}

export default function ProJointComparison({ userAngles, exerciseCategory }) {
  if (!userAngles) return null;
  const pro = PRO_ANGLES[exerciseCategory] || PRO_ANGLES.other;

  const userAvg = {
    knee:     ((userAngles.knee_left || 0) + (userAngles.knee_right || 0)) / 2,
    hip:      ((userAngles.hip_left || 0) + (userAngles.hip_right || 0)) / 2,
    shoulder: ((userAngles.shoulder_left || 0) + (userAngles.shoulder_right || 0)) / 2,
    ankle:    ((userAngles.ankle_left || 0) + (userAngles.ankle_right || 0)) / 2,
  };

  const joints = [
    { label: "Knee", user: userAvg.knee, pro: pro.knee },
    { label: "Hip",  user: userAvg.hip,  pro: pro.hip  },
    { label: "Shoulder", user: userAvg.shoulder, pro: pro.shoulder },
    { label: "Ankle", user: userAvg.ankle, pro: pro.ankle },
  ];

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <h3 className="font-heading font-semibold text-foreground mb-4">Pro vs. Your Joint Angles</h3>
      <div className="space-y-3">
        {joints.map((j, i) => {
          const d = delta(j.user, j.pro);
          const abs = d !== null ? Math.abs(d) : 0;
          const pctUser = Math.min((j.user / 180) * 100, 100);
          const pctPro  = Math.min((j.pro  / 180) * 100, 100);
          return (
            <motion.div key={j.label} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-muted-foreground w-16">{j.label}</span>
                <div className="flex items-center gap-3 text-xs">
                  <span className="text-muted-foreground">Pro: <span className="text-foreground font-medium">{j.pro}°</span></span>
                  <span className="text-muted-foreground">You: <span className="text-foreground font-medium">{Math.round(j.user)}°</span></span>
                  <DeltaBadge d={d} />
                </div>
              </div>
              <div className="relative h-2 bg-muted rounded-full">
                {/* Pro marker */}
                <div className="absolute top-0 bottom-0 w-0.5 bg-primary/50 rounded-full" style={{ left: `${pctPro}%` }} />
                {/* User bar */}
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${pctUser}%` }}
                  transition={{ duration: 0.6, delay: i * 0.06 }}
                  className={`h-2 rounded-full ${abs <= 5 ? "bg-green-500" : abs <= 15 ? "bg-yellow-400" : "bg-red-500"}`}
                />
              </div>
            </motion.div>
          );
        })}
      </div>
      <p className="text-[10px] text-muted-foreground mt-3">Pink line = professional benchmark. Bar = your average angle.</p>
    </div>
  );
}

// Joint weights per exercise — primary joints matter more
const JOINT_WEIGHTS = {
  squat:          { knee: 0.40, hip: 0.35, shoulder: 0.10, ankle: 0.15 },
  lunge:          { knee: 0.40, hip: 0.35, shoulder: 0.10, ankle: 0.15 },
  deadlift:       { knee: 0.20, hip: 0.50, shoulder: 0.20, ankle: 0.10 },
  bench_press:    { knee: 0.05, hip: 0.10, shoulder: 0.70, ankle: 0.15 },
  overhead_press: { knee: 0.05, hip: 0.15, shoulder: 0.70, ankle: 0.10 },
  barbell_row:    { knee: 0.10, hip: 0.40, shoulder: 0.40, ankle: 0.10 },
  push_up:        { knee: 0.10, hip: 0.20, shoulder: 0.60, ankle: 0.10 },
  other:          { knee: 0.25, hip: 0.25, shoulder: 0.25, ankle: 0.25 },
};

// Utility: compute form score from ideal angles
export function computeFormScoreFromAngles(userAngles, exerciseCategory) {
  const pro = PRO_ANGLES[exerciseCategory] || PRO_ANGLES.other;
  const weights = JOINT_WEIGHTS[exerciseCategory] || JOINT_WEIGHTS.other;

  const joints = [
    { user: ((userAngles.knee_left || 0) + (userAngles.knee_right || 0)) / 2, pro: pro.knee, weight: weights.knee },
    { user: ((userAngles.hip_left  || 0) + (userAngles.hip_right  || 0)) / 2, pro: pro.hip,  weight: weights.hip  },
    { user: ((userAngles.shoulder_left || 0) + (userAngles.shoulder_right || 0)) / 2, pro: pro.shoulder, weight: weights.shoulder },
    { user: ((userAngles.ankle_left || 0) + (userAngles.ankle_right || 0)) / 2, pro: pro.ankle, weight: weights.ankle },
  ];

  // Scoring curve: diff=0→100, diff=5→96, diff=10→88, diff=15→78, diff=20→66, diff=30→42
  const weightedScore = joints.reduce((sum, { user, pro, weight }) => {
    const diff = Math.abs(user - pro);
    const score = Math.max(0, 100 - Math.pow(diff, 1.45) * 0.11);
    return sum + score * weight;
  }, 0);

  return Math.round(Math.max(20, Math.min(100, weightedScore)));
}