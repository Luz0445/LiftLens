import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function WorkoutCountdown({ onComplete }) {
  const [count, setCount] = useState(3);

  useEffect(() => {
    if (count === 0) {
      const t = setTimeout(() => onComplete(), 500);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setCount((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [count, onComplete]);

  return (
    <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center z-20 rounded-t-2xl">
      <AnimatePresence mode="wait">
        <motion.div
          key={count}
          initial={{ scale: 0.4, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 1.6, opacity: 0 }}
          transition={{ duration: 0.45 }}
          className="flex flex-col items-center gap-4"
        >
          {count > 0 ? (
            <>
              <p className="text-8xl font-heading font-bold text-primary">{count}</p>
              <p className="text-white/70 text-sm font-medium uppercase tracking-widest">Get ready…</p>
            </>
          ) : (
            <>
              <p className="text-5xl font-heading font-bold text-primary">GO!</p>
              <p className="text-white/70 text-sm font-medium uppercase tracking-widest">Recording started</p>
            </>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}