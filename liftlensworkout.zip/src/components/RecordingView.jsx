import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Square, Loader2, AlertCircle, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { usePoseDetection } from "../hooks/usePoseDetection";
import { processBadgesAndStreak } from "../hooks/useBadgeSystem";
import BadgeToast from "./BadgeToast";
import { computeFormScoreFromAngles, PRO_ANGLES } from "./ProJointComparison";

export default function RecordingView({ exercise, onComplete, onBack }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  const [cameraError, setCameraError] = useState(null);
  const [cameraReady, setCameraReady] = useState(false);
  const [recording, setRecording] = useState(false);
  const [paused, setPaused] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [timer, setTimer] = useState(0);
  const [newBadges, setNewBadges] = useState([]);
  const [showBadges, setShowBadges] = useState(false);
  const [waitingForSignal] = useState(false);
  const [countdown, setCountdown] = useState(null);
  const [targetSets, setTargetSets] = useState(3);
  const [targetRepsPerSet, setTargetRepsPerSet] = useState(8);
  const [currentSet, setCurrentSet] = useState(1);
  const [totalReps, setTotalReps] = useState(0);
  const [displayRep, setDisplayRep] = useState(0);
  const timerRef = useRef(null);
  const sessionIdRef = useRef(null);
  const prevRepCount = useRef(0);
  const animFrameRef = useRef(null);
  const angleHistoryRef = useRef([]); // accumulate live angles during recording
  const stanceWarningCountRef = useRef(0); // track how many frames had stance issues

  const { isModelLoaded, repCount, currentAngle, loadingStatus, resetReps, stanceWarning } = usePoseDetection({
    videoRef,
    canvasRef,
    active: cameraReady && !paused,
    exerciseCategory: exercise?.category,
  });

  // Smooth rep counter animation
  useEffect(() => {
    if (repCount === prevRepCount.current) return;
    const start = prevRepCount.current;
    const end = repCount;
    const startTime = performance.now();
    const duration = 300;
    const animate = (now) => {
      const progress = Math.min((now - startTime) / duration, 1);
      setDisplayRep(Math.round(start + (end - start) * progress));
      if (progress < 1) animFrameRef.current = requestAnimationFrame(animate);
      else prevRepCount.current = end;
    };
    animFrameRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [repCount]);

  useEffect(() => {
    startCamera();
    return () => cleanup();
  }, []);

  async function startCamera() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraReady(true);
    } catch (err) {
      setCameraError(err.message || "Camera access denied.");
    }
  }

  function cleanup() {
    if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
    if (timerRef.current) clearInterval(timerRef.current);
  }

  // Accumulate angle samples while recording
  useEffect(() => {
    if (recording && !paused && currentAngle !== null) {
      angleHistoryRef.current.push(currentAngle);
    }
  }, [currentAngle, recording, paused]);

  // Count stance warning frames
  useEffect(() => {
    if (recording && !paused && stanceWarning) {
      stanceWarningCountRef.current += 1;
    }
  }, [stanceWarning, recording, paused]);



  function beginRecording() {
    angleHistoryRef.current = [];
    stanceWarningCountRef.current = 0;
    resetReps();
    prevRepCount.current = 0;
    setDisplayRep(0);
    setTotalReps(0);
    setCurrentSet(1);
    setPaused(false);
    setCountdown(3);
    // Countdown 3-2-1 then start
    let count = 3;
    const cdInterval = setInterval(() => {
      count -= 1;
      if (count <= 0) {
        clearInterval(cdInterval);
        setCountdown(null);
        setRecording(true);
        setTimer(0);
        timerRef.current = setInterval(() => setTimer((t) => t + 1), 1000);
      } else {
        setCountdown(count);
      }
    }, 1000);
  }

  function startRecording() {
    beginRecording();
  }

  function togglePause() {
    setPaused((p) => {
      if (!p) {
        // Pausing — accumulate reps
        setTotalReps((prev) => prev + repCount);
      }
      return !p;
    });
  }

  function nextSet() {
    setTotalReps((prev) => prev + repCount);
    resetReps();
    prevRepCount.current = 0;
    setDisplayRep(0);
    setCurrentSet((s) => Math.min(s + 1, targetSets));
    setPaused(false);
  }

  async function stopRecording() {
    setRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
    cleanup();
    setAnalyzing(true);

    const repsCount = Math.max(totalReps + repCount, 1);
    const category = exercise?.category || "other";
    const pro = PRO_ANGLES[category] || PRO_ANGLES.other;

    // Use real tracked angles if available, else fallback to pro angles (no penalty)
    const history = angleHistoryRef.current;
    const avgAngle = history.length > 0
      ? Math.round(history.reduce((a, b) => a + b, 0) / history.length)
      : null;

    // Build joint angles: use tracked primary angle for the relevant joints,
    // assume other joints are near-ideal (they aren't being tracked)
    const primaryAngle = avgAngle !== null ? avgAngle : pro.knee;
    const jointAngles = {
      knee_left:      category === "squat" || category === "lunge" ? primaryAngle : pro.knee,
      knee_right:     category === "squat" || category === "lunge" ? primaryAngle : pro.knee,
      hip_left:       category === "deadlift" ? primaryAngle : pro.hip,
      hip_right:      category === "deadlift" ? primaryAngle : pro.hip,
      shoulder_left:  ["bench_press", "overhead_press", "barbell_row"].includes(category) ? primaryAngle : pro.shoulder,
      shoulder_right: ["bench_press", "overhead_press", "barbell_row"].includes(category) ? primaryAngle : pro.shoulder,
      ankle_left:  pro.ankle,
      ankle_right: pro.ankle,
    };

    const formScore = avgAngle !== null
      ? Math.min(100, Math.max(20, computeFormScoreFromAngles(jointAngles, category)))
      : 50; // fallback if no angle data collected

    const proComparison = {
      knee_delta:     Math.round(((jointAngles.knee_left + jointAngles.knee_right) / 2) - pro.knee),
      hip_delta:      Math.round(((jointAngles.hip_left  + jointAngles.hip_right)  / 2) - pro.hip),
      shoulder_delta: Math.round(((jointAngles.shoulder_left + jointAngles.shoulder_right) / 2) - pro.shoulder),
      ankle_delta:    0,
    };

    const repData = Array.from({ length: repsCount }, (_, i) => {
      const degradation = i > repsCount * 0.6 ? (i - repsCount * 0.6) * 4 : 0;
      const score = Math.min(100, Math.max(35, formScore + Math.floor(Math.random() * 10) - 5 - degradation));
      return {
        rep_number: i + 1,
        form_score: Math.round(score),
        depth_score: Math.round(score - Math.floor(Math.random() * 12)),
        alignment_score: Math.round(score + Math.floor(Math.random() * 8) - 4),
        eccentric_speed: +(1.5 + Math.random()).toFixed(1),
        concentric_speed: +(0.8 + Math.random() * 0.5).toFixed(1),
        status: score >= 75 ? "stable" : score >= 58 ? "warning" : "breakdown",
      };
    });

    const fatigueRep = repData.findIndex((r) => r.status !== "stable");
    const cuePool = exercise?.coaching_tips || [
      "Focus on controlled descent",
      "Keep your core tight throughout the movement",
      "Drive through your heels on the way up",
    ];

    const allSessions = await base44.entities.WorkoutSession.list("-created_date", 100);
    const me = await base44.auth.me().catch(() => null);

    const session = await base44.entities.WorkoutSession.create({
      exercise: exercise?.name || "Unknown Exercise",
      exercise_category: category,
      user_name: me?.full_name || me?.email || "Athlete",
      form_score: formScore,
      reps_completed: repsCount,
      sets_completed: targetSets,
      target_reps_per_set: targetRepsPerSet,
      consistency_rating: formScore >= 80 ? "excellent" : formScore >= 68 ? "good" : formScore >= 55 ? "fair" : "poor",
      primary_focus_area: "Depth & alignment",
      coaching_cues: cuePool.slice(0, 3),
      strengths: ["Good tempo control", "Consistent starting position"],
      improvement_areas: ["Depth at bottom position", "Knee tracking on later reps"],
      injury_risks: (() => {
        const risks = [];
        const kneeAvg = (jointAngles.knee_left + jointAngles.knee_right) / 2;
        const hipAvg  = (jointAngles.hip_left  + jointAngles.hip_right)  / 2;
        const shouAvg = (jointAngles.shoulder_left + jointAngles.shoulder_right) / 2;
        const kneeDiff = Math.abs(kneeAvg - pro.knee);
        const hipDiff  = Math.abs(hipAvg  - pro.hip);
        const shouDiff = Math.abs(shouAvg - pro.shoulder);
        if (["squat","lunge"].includes(category) && kneeDiff > 15) {
          risks.push({ area: "Knee", severity: kneeDiff > 30 ? "high" : "moderate", description: `Knee angle ${Math.round(kneeAvg)}° vs ideal ${pro.knee}°. Excessive deviation stresses the joint.`, exerciseCategory: category });
        }
        if (["deadlift","barbell_row"].includes(category) && hipDiff > 15) {
          risks.push({ area: "Hip / Lower Back", severity: hipDiff > 30 ? "high" : "moderate", description: `Hip angle ${Math.round(hipAvg)}° vs ideal ${pro.hip}°. Maintain a proper hinge to protect the lumbar spine.`, exerciseCategory: category });
        }
        if (["bench_press","overhead_press","barbell_row"].includes(category) && shouDiff > 15) {
          risks.push({ area: "Shoulder / Elbow", severity: shouDiff > 30 ? "high" : "moderate", description: `Shoulder angle ${Math.round(shouAvg)}° vs ideal ${pro.shoulder}°. Flared elbows or improper path increase rotator cuff stress.`, exerciseCategory: category });
        }
        // Stance width risk
        if (['squat', 'lunge', 'deadlift', 'overhead_press'].includes(category) && stanceWarningCountRef.current > 30) {
          risks.push({ area: "Stance Width", severity: stanceWarningCountRef.current > 80 ? "high" : "moderate", description: "Your feet were detected too wide or too narrow. For most exercises, aim for shoulder-width stance to maintain knee tracking and balance.", exerciseCategory: category });
        }
        if (formScore < 55 && risks.length === 0) {
          risks.push({ area: "General Form", severity: "moderate", description: "Overall joint angles deviate significantly from ideal. Reduce load and focus on controlled technique.", exerciseCategory: category });
        }
        return risks;
      })(),
      rep_data: repData,
      joint_angles: jointAngles,
      pro_joint_comparison: proComparison,
      symmetry_score: 70 + Math.floor(Math.random() * 22),
      depth_improvement: Math.floor(Math.random() * 20) - 8,
      alignment_improvement: Math.floor(Math.random() * 15) - 5,
      fatigue_onset_rep: fatigueRep > 0 ? fatigueRep + 1 : null,
      duration_seconds: timer,
    });

    sessionIdRef.current = session.id;

    // Process badges & streak
    const { newBadges: earned } = await processBadgesAndStreak({
      session,
      allSessions,
    });

    if (earned.length > 0) {
      setNewBadges(earned);
      setShowBadges(true);
    } else {
      onComplete(session.id);
    }
  }

  const formatTime = (s) =>
    `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  if (showBadges && newBadges.length > 0) {
    return (
      <BadgeToast
        badges={newBadges}
        onDone={() => {
          setShowBadges(false);
          onComplete(sessionIdRef.current);
        }}
      />
    );
  }

  if (analyzing) {
    return (
      <div className="flex flex-col items-center justify-center h-[50vh] gap-4">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity, ease: "linear" }}>
          <Loader2 className="w-10 h-10 text-primary" />
        </motion.div>
        <p className="font-heading font-semibold text-foreground">Analyzing your form...</p>
        <p className="text-sm text-muted-foreground">Processing {repCount} detected reps</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <button onClick={() => { cleanup(); onBack(); }} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="w-4 h-4" />
        Back
      </button>

      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        {/* Camera + Canvas overlay */}
        <div className="aspect-video bg-black relative">
          {cameraError ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
              <AlertCircle className="w-10 h-10 text-destructive" />
              <p className="text-sm text-destructive">{cameraError}</p>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="absolute inset-0 w-full h-full object-cover"
                onLoadedMetadata={() => {
                  if (canvasRef.current && videoRef.current) {
                    canvasRef.current.width = videoRef.current.videoWidth;
                    canvasRef.current.height = videoRef.current.videoHeight;
                  }
                }}
              />
              {/* Pose canvas */}
              <canvas
                ref={canvasRef}
                className="absolute inset-0 w-full h-full object-cover"
              />
            </>
          )}



          {/* 3-2-1 Countdown overlay */}
          {countdown !== null && (
            <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center z-30">
              <AnimatePresence mode="wait">
                <motion.p
                  key={countdown}
                  initial={{ scale: 0.4, opacity: 0 }}
                  animate={{ scale: 1.2, opacity: 1 }}
                  exit={{ scale: 1.8, opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="text-8xl font-heading font-bold text-primary drop-shadow-lg"
                >
                  {countdown}
                </motion.p>
              </AnimatePresence>
              <p className="text-white/70 text-sm mt-4 font-heading">Get ready...</p>
            </div>
          )}

          {/* Model loading overlay */}
          {cameraReady && !isModelLoaded && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50">
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="w-7 h-7 text-primary animate-spin" />
                <p className="text-xs text-white/80">{loadingStatus}</p>
              </div>
            </div>
          )}

          {/* REC badge */}
          {recording && (
            <motion.div
              animate={{ opacity: [1, 0.4, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="absolute top-3 right-3 flex items-center gap-2 bg-destructive/90 text-white px-3 py-1.5 rounded-full"
            >
              <div className="w-2 h-2 rounded-full bg-white" />
              <span className="text-xs font-bold">REC</span>
            </motion.div>
          )}

          {/* Timer */}
          <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-sm px-3 py-1.5 rounded-full">
            <span className="text-sm font-heading font-bold text-white">{formatTime(timer)}</span>
          </div>

          {/* Live stats during recording */}
          {recording && (
            <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
              {/* Rep counter */}
              <div className="bg-black/70 backdrop-blur-sm rounded-xl px-4 py-2 text-center min-w-[64px]">
                <AnimatePresence mode="wait">
                  <motion.p
                    key={displayRep}
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 8 }}
                    transition={{ duration: 0.15 }}
                    className="text-3xl font-heading font-bold text-primary"
                  >
                    {displayRep}
                  </motion.p>
                </AnimatePresence>
                <p className="text-[10px] text-white/70 uppercase tracking-wider">Reps</p>
              </div>

              {/* Set tracker */}
              <div className="bg-black/70 backdrop-blur-sm rounded-xl px-4 py-2 text-center">
                <p className="text-lg font-heading font-bold text-white">{currentSet}<span className="text-white/50 text-sm">/{targetSets}</span></p>
                <p className="text-[10px] text-white/70 uppercase tracking-wider">Set</p>
              </div>

              {/* Joint angle */}
              {currentAngle !== null && !paused && (
                <div className="bg-black/70 backdrop-blur-sm rounded-xl px-4 py-2 text-center flex items-center gap-2">
                  <Activity className="w-3.5 h-3.5 text-primary" />
                  <div>
                    <p className="text-lg font-heading font-bold text-white">{currentAngle}°</p>
                    <p className="text-[10px] text-white/70">Angle</p>
                  </div>
                </div>
              )}

              {/* Stance width warning */}
              {stanceWarning && !paused && (
                <div className="absolute top-16 left-3 right-3 z-20">
                  <div className="bg-yellow-500/90 backdrop-blur-sm text-black text-xs font-semibold px-3 py-1.5 rounded-full text-center">
                    {stanceWarning === 'wide' ? '⚠️ Feet too wide — bring closer to shoulder width' : '⚠️ Feet too narrow — spread to shoulder width'}
                  </div>
                </div>
              )}

              {/* Calibration hint */}
              {repCount === 0 && !paused && (
                <div className="bg-primary/20 border border-primary/40 backdrop-blur-sm rounded-xl px-3 py-2">
                  <p className="text-[10px] text-primary font-medium">Complete 1 rep to calibrate</p>
                </div>
              )}
            </div>
          )}

          {/* Pause overlay */}
          {paused && recording && (
            <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center gap-4">
              <p className="text-white font-heading font-bold text-xl">Paused</p>
              <div className="flex items-center gap-4 bg-black/70 rounded-2xl p-4">
                <button onClick={() => setDisplayRep((r) => Math.max(0, r - 1))} className="w-10 h-10 rounded-full bg-white/10 text-white font-bold text-xl flex items-center justify-center hover:bg-white/20">−</button>
                <div className="text-center">
                  <p className="text-4xl font-heading font-bold text-primary">{displayRep}</p>
                  <p className="text-xs text-white/60">Reps this set</p>
                </div>
                <button onClick={() => setDisplayRep((r) => r + 1)} className="w-10 h-10 rounded-full bg-white/10 text-white font-bold text-xl flex items-center justify-center hover:bg-white/20">+</button>
              </div>
              {currentSet < targetSets && (
                <button onClick={nextSet} className="px-6 py-2 bg-primary text-white rounded-full text-sm font-semibold font-heading">
                  Next Set ({currentSet + 1}/{targetSets})
                </button>
              )}
            </div>
          )}
        </div>

        <div className="p-5 space-y-3">
          {/* Model status */}
          {cameraReady && (
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isModelLoaded ? "bg-primary" : "bg-muted-foreground animate-pulse"}`} />
              <p className="text-xs text-muted-foreground">
                {isModelLoaded ? `AI pose tracking active · Tracking: ${exercise?.name}` : loadingStatus}
              </p>
            </div>
          )}

          {!recording && countdown === null ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground font-medium">Sets to complete</p>
                <div className="flex items-center gap-3">
                  <button onClick={() => setTargetSets((s) => Math.max(1, s - 1))} className="w-8 h-8 rounded-full bg-secondary text-foreground font-bold flex items-center justify-center hover:bg-muted">−</button>
                  <span className="text-lg font-heading font-bold text-foreground w-6 text-center">{targetSets}</span>
                  <button onClick={() => setTargetSets((s) => s + 1)} className="w-8 h-8 rounded-full bg-secondary text-foreground font-bold flex items-center justify-center hover:bg-muted">+</button>
                </div>
              </div>
              <Button
                onClick={startRecording}
                disabled={!!cameraError || !isModelLoaded}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-heading font-semibold h-12"
              >
                {!isModelLoaded ? "Loading AI Model..." : "Start Recording"}
              </Button>
            </div>
          ) : (
            <div className="flex gap-3">
              <Button
                onClick={togglePause}
                variant="outline"
                className="flex-1 font-heading font-semibold h-12"
              >
                {paused ? "Resume" : "Pause"}
              </Button>
              <Button
                onClick={stopRecording}
                variant="destructive"
                className="flex-1 font-heading font-semibold h-12"
              >
                <Square className="w-4 h-4 mr-2 fill-current" />
                Finish
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}