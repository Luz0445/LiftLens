import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Target } from "lucide-react";

export default function ActiveGoalsPanel() {
  const [goals, setGoals] = useState([]);

  useEffect(() => {
    base44.entities.UserGoal.filter({ status: "active" }, "-created_date", 5).then(setGoals);
  }, []);

  if (!goals.length) return null;

  return (
    <div className="bg-muted/60 border border-border rounded-xl p-4">
      <div className="flex items-center gap-2 mb-3">
        <Target className="w-4 h-4 text-primary" />
        <p className="text-xs font-heading font-semibold text-foreground uppercase tracking-wider">Active Goals</p>
      </div>
      <div className="space-y-2.5">
        {goals.map((g) => {
          const pct = Math.min(((g.current_value || 0) / g.target_value) * 100, 100);
          return (
            <div key={g.id}>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-foreground font-medium truncate max-w-[70%]">{g.title}</span>
                <span className="text-muted-foreground">{g.current_value || 0}/{g.target_value}</span>
              </div>
              <div className="h-1.5 bg-muted rounded-full">
                <div className="h-1.5 bg-primary rounded-full transition-all" style={{ width: `${pct}%` }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}