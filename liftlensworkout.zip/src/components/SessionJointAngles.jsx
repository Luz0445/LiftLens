import { motion } from "framer-motion";

export default function SessionJointAngles({ angles }) {
  if (!angles) return null;

  const joints = [
    { key: "knee", label: "Knee", left: angles.knee_left, right: angles.knee_right },
    { key: "hip", label: "Hip", left: angles.hip_left, right: angles.hip_right },
    { key: "shoulder", label: "Shoulder", left: angles.shoulder_left, right: angles.shoulder_right },
    { key: "ankle", label: "Ankle", left: angles.ankle_left, right: angles.ankle_right },
  ];

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <h3 className="font-heading font-semibold text-foreground mb-4">Joint Angles (Avg)</h3>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {joints.map((joint, i) => {
          const diff = Math.abs((joint.left || 0) - (joint.right || 0));
          const symmetric = diff < 10;
          return (
            <motion.div
              key={joint.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-muted/50 rounded-lg p-3"
            >
              <p className="text-xs text-muted-foreground mb-2">{joint.label}</p>
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-[10px] text-muted-foreground">L</p>
                  <p className="text-lg font-heading font-bold text-foreground">{joint.left || "—"}°</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-muted-foreground">R</p>
                  <p className="text-lg font-heading font-bold text-foreground">{joint.right || "—"}°</p>
                </div>
              </div>
              <div className={`text-[10px] mt-2 ${symmetric ? "text-primary" : "text-accent"}`}>
                {symmetric ? "Symmetric" : `${diff}° imbalance`}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}