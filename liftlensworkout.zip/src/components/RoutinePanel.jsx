import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Play, ChevronDown, ChevronUp, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";

export default function RoutinePanel({ exercises, onStartRoutine }) {
  const queryClient = useQueryClient();
  const [expanded, setExpanded] = useState(null);
  const [creating, setCreating] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [selectedExercises, setSelectedExercises] = useState([]);

  const { data: routines = [] } = useQuery({
    queryKey: ["routines"],
    queryFn: () => base44.entities.WorkoutRoutine.list("-created_date", 20),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.WorkoutRoutine.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["routines"] });
      setCreating(false);
      setNewTitle("");
      setSelectedExercises([]);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.WorkoutRoutine.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["routines"] }),
  });

  function toggleExercise(ex) {
    setSelectedExercises((prev) =>
      prev.find((e) => e.exercise_id === ex.id)
        ? prev.filter((e) => e.exercise_id !== ex.id)
        : [...prev, { exercise_id: ex.id, exercise_name: ex.name, exercise_category: ex.category, sets: 3, reps_per_set: 8, rest_seconds: 60 }]
    );
  }

  function updateExerciseField(id, field, value) {
    setSelectedExercises((prev) =>
      prev.map((e) => e.exercise_id === id ? { ...e, [field]: Number(value) } : e)
    );
  }

  function saveRoutine() {
    if (!newTitle || selectedExercises.length === 0) return;
    createMutation.mutate({
      title: newTitle,
      exercises: selectedExercises,
      estimated_duration_minutes: selectedExercises.reduce((sum, e) => sum + (e.sets * (e.reps_per_set * 3 + e.rest_seconds)) / 60, 0) | 0,
      difficulty: "intermediate",
    });
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-heading font-semibold text-foreground">Saved Routines</h3>
        <Button size="sm" variant="outline" className="border-primary/30 text-primary text-xs" onClick={() => setCreating(true)}>
          <Plus className="w-3.5 h-3.5 mr-1" /> New Routine
        </Button>
      </div>

      {/* Create Routine */}
      <AnimatePresence>
        {creating && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-muted border border-primary/20 rounded-xl p-4 space-y-3 overflow-hidden"
          >
            <Input
              placeholder="Routine name..."
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="bg-card border-border text-sm"
            />
            <p className="text-xs text-muted-foreground">Select exercises:</p>
            <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
              {exercises.map((ex) => {
                const selected = selectedExercises.find((e) => e.exercise_id === ex.id);
                return (
                  <button
                    key={ex.id}
                    onClick={() => toggleExercise(ex)}
                    className={`text-left p-2.5 rounded-lg border text-xs transition-all ${selected ? "bg-primary/10 border-primary/50 text-primary" : "bg-card border-border text-muted-foreground hover:border-primary/30"}`}
                  >
                    {ex.name}
                  </button>
                );
              })}
            </div>
            {selectedExercises.length > 0 && (
              <div className="space-y-2">
                {selectedExercises.map((ex) => (
                  <div key={ex.exercise_id} className="flex items-center gap-2 text-xs">
                    <span className="flex-1 text-foreground truncate">{ex.exercise_name}</span>
                    <input type="number" value={ex.sets} min={1} onChange={(e) => updateExerciseField(ex.exercise_id, "sets", e.target.value)} className="w-10 bg-card border border-border rounded p-1 text-center text-foreground" />
                    <span className="text-muted-foreground">sets</span>
                    <input type="number" value={ex.reps_per_set} min={1} onChange={(e) => updateExerciseField(ex.exercise_id, "reps_per_set", e.target.value)} className="w-10 bg-card border border-border rounded p-1 text-center text-foreground" />
                    <span className="text-muted-foreground">reps</span>
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <Button size="sm" onClick={saveRoutine} disabled={!newTitle || selectedExercises.length === 0 || createMutation.isPending} className="bg-primary text-primary-foreground text-xs flex-1">
                Save Routine
              </Button>
              <Button size="sm" variant="outline" onClick={() => setCreating(false)} className="text-xs">Cancel</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Routine List */}
      {routines.length === 0 && !creating && (
        <p className="text-xs text-muted-foreground text-center py-4">No routines yet. Create one to plan your workouts!</p>
      )}
      <div className="space-y-2">
        {routines.map((routine) => (
          <div key={routine.id} className="bg-card border border-border rounded-xl overflow-hidden">
            <button
              className="w-full flex items-center justify-between p-4 text-left"
              onClick={() => setExpanded(expanded === routine.id ? null : routine.id)}
            >
              <div>
                <p className="text-sm font-medium text-foreground">{routine.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {routine.exercises?.length || 0} exercises · ~{routine.estimated_duration_minutes || "?"}min
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  className="bg-primary text-primary-foreground text-xs h-7 px-3"
                  onClick={(e) => { e.stopPropagation(); onStartRoutine(routine); }}
                >
                  <Play className="w-3 h-3 mr-1" /> Start
                </Button>
                {expanded === routine.id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
              </div>
            </button>
            <AnimatePresence>
              {expanded === routine.id && (
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: "auto" }}
                  exit={{ height: 0 }}
                  className="overflow-hidden border-t border-border"
                >
                  <div className="p-4 space-y-2">
                    {(routine.exercises || []).map((ex, i) => (
                      <div key={i} className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-[10px]">{i + 1}</span>
                        <span className="flex-1 text-foreground">{ex.exercise_name}</span>
                        <span>{ex.sets}×{ex.reps_per_set} reps</span>
                        <span>{ex.rest_seconds}s rest</span>
                      </div>
                    ))}
                    <button
                      onClick={() => deleteMutation.mutate(routine.id)}
                      className="flex items-center gap-1 text-xs text-destructive/60 hover:text-destructive mt-2 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" /> Delete routine
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
}