// Simple stick-figure SVG hints for correct form per exercise/joint
const STANCE_SVG = (
  <svg viewBox="0 0 80 100" className="w-16 h-20">
    {/* body */}
    <circle cx="40" cy="12" r="5" fill="hsl(330,85%,75%)"/>
    <line x1="40" y1="17" x2="40" y2="50" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
    {/* left leg */}
    <line x1="40" y1="50" x2="27" y2="75" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
    <line x1="27" y1="75" x2="27" y2="92" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
    {/* right leg */}
    <line x1="40" y1="50" x2="53" y2="75" stroke="hsl(300,70%,60%)" strokeWidth="2.5" strokeLinecap="round"/>
    <line x1="53" y1="75" x2="53" y2="92" stroke="hsl(300,70%,60%)" strokeWidth="2.5" strokeLinecap="round"/>
    {/* shoulder width guide */}
    <line x1="30" y1="30" x2="50" y2="30" stroke="#4ade80" strokeWidth="1.2" strokeDasharray="2,2"/>
    <line x1="27" y1="92" x2="53" y2="92" stroke="#4ade80" strokeWidth="1.5"/>
    {/* arrows */}
    <text x="2" y="97" fontSize="5.5" fill="#4ade80">feet = shoulder width</text>
  </svg>
);

const HINTS = {
  Knee: {
    squat: { label: "Ideal squat depth: ~90° knee angle", svg: (
      <svg viewBox="0 0 80 100" className="w-16 h-20">
        {/* torso */}
        <line x1="40" y1="10" x2="40" y2="40" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        {/* hip to knee */}
        <line x1="40" y1="40" x2="28" y2="65" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        {/* knee to ankle - 90 deg = horizontal */}
        <line x1="28" y1="65" x2="18" y2="85" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        {/* right side */}
        <line x1="40" y1="40" x2="52" y2="65" stroke="hsl(300,70%,60%)" strokeWidth="2" strokeLinecap="round"/>
        <line x1="52" y1="65" x2="62" y2="85" stroke="hsl(300,70%,60%)" strokeWidth="2" strokeLinecap="round"/>
        {/* angle arc */}
        <path d="M 22 62 A 10 10 0 0 1 32 72" stroke="#4ade80" strokeWidth="1.5" fill="none"/>
        {/* joints */}
        <circle cx="40" cy="40" r="3" fill="hsl(330,85%,75%)"/>
        <circle cx="28" cy="65" r="4" fill="#4ade80"/>
        <circle cx="52" cy="65" r="4" fill="hsl(300,70%,70%)"/>
        <text x="4" y="97" fontSize="6" fill="#4ade80">~90° knee</text>
      </svg>
    )},
    lunge: { label: "Ideal lunge: ~90° front knee, back knee hovering", svg: (
      <svg viewBox="0 0 80 100" className="w-16 h-20">
        <line x1="40" y1="8" x2="40" y2="38" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="40" y1="38" x2="30" y2="60" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="30" y1="60" x2="20" y2="80" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="40" y1="38" x2="55" y2="58" stroke="hsl(300,70%,60%)" strokeWidth="2" strokeLinecap="round"/>
        <line x1="55" y1="58" x2="60" y2="80" stroke="hsl(300,70%,60%)" strokeWidth="2" strokeLinecap="round"/>
        <circle cx="30" cy="60" r="4" fill="#4ade80"/>
        <circle cx="55" cy="58" r="4" fill="hsl(300,70%,70%)"/>
        <text x="2" y="97" fontSize="6" fill="#4ade80">90° front knee</text>
      </svg>
    )},
  },
  "Hip / Lower Back": {
    deadlift: { label: "Ideal deadlift hip hinge: ~45° hip angle", svg: (
      <svg viewBox="0 0 80 100" className="w-16 h-20">
        {/* leaning torso */}
        <line x1="50" y1="15" x2="30" y2="42" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        {/* hip to knee - mostly straight */}
        <line x1="30" y1="42" x2="32" y2="70" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        {/* knee to ankle */}
        <line x1="32" y1="70" x2="30" y2="90" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        {/* angle arc at hip */}
        <path d="M 36 46 A 10 10 0 0 1 40 55" stroke="#4ade80" strokeWidth="1.5" fill="none"/>
        <circle cx="30" cy="42" r="4" fill="#4ade80"/>
        <circle cx="32" cy="70" r="3" fill="hsl(330,85%,75%)"/>
        <text x="2" y="97" fontSize="6" fill="#4ade80">~45° hip hinge</text>
      </svg>
    )},
  },
  "Shoulder / Elbow": {
    bench_press: { label: "Ideal bench: ~75° shoulder angle", svg: (
      <svg viewBox="0 0 80 100" className="w-16 h-20">
        <line x1="40" y1="40" x2="40" y2="70" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="40" y1="45" x2="15" y2="50" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="15" y1="50" x2="12" y2="30" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="40" y1="45" x2="65" y2="50" stroke="hsl(300,70%,60%)" strokeWidth="2" strokeLinecap="round"/>
        <line x1="65" y1="50" x2="68" y2="30" stroke="hsl(300,70%,60%)" strokeWidth="2" strokeLinecap="round"/>
        <circle cx="15" cy="50" r="4" fill="#4ade80"/>
        <circle cx="65" cy="50" r="4" fill="hsl(300,70%,70%)"/>
        <text x="8" y="97" fontSize="6" fill="#4ade80">~75° elbows</text>
      </svg>
    )},
  },
  Shoulder: {
    overhead_press: { label: "Press straight overhead, core tight", svg: (
      <svg viewBox="0 0 80 100" className="w-16 h-20">
        <line x1="40" y1="30" x2="40" y2="60" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="40" y1="35" x2="20" y2="42" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="20" y1="42" x2="18" y2="18" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="40" y1="35" x2="60" y2="42" stroke="hsl(300,70%,60%)" strokeWidth="2" strokeLinecap="round"/>
        <line x1="60" y1="42" x2="62" y2="18" stroke="hsl(300,70%,60%)" strokeWidth="2" strokeLinecap="round"/>
        <circle cx="20" cy="42" r="4" fill="#4ade80"/>
        <circle cx="60" cy="42" r="4" fill="hsl(300,70%,70%)"/>
        <text x="6" y="97" fontSize="6" fill="#4ade80">arms vertical</text>
      </svg>
    )},
    barbell_row: { label: "Pull to lower chest, 90° elbow", svg: (
      <svg viewBox="0 0 80 100" className="w-16 h-20">
        <line x1="48" y1="15" x2="30" y2="40" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="30" y1="40" x2="15" y2="38" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="15" y1="38" x2="12" y2="20" stroke="hsl(330,85%,62%)" strokeWidth="2.5" strokeLinecap="round"/>
        <circle cx="15" cy="38" r="4" fill="#4ade80"/>
        <text x="4" y="97" fontSize="6" fill="#4ade80">90° pull angle</text>
      </svg>
    )},
  },
  "Stance Width": {
    squat:          { label: "Feet shoulder-width apart, toes slightly out", svg: STANCE_SVG },
    lunge:          { label: "Front foot hip-width, controlled stride", svg: STANCE_SVG },
    deadlift:       { label: "Feet hip-width apart for conventional pull", svg: STANCE_SVG },
    overhead_press: { label: "Feet shoulder-width for a stable base", svg: STANCE_SVG },
  },
};

export default function FormCorrectionHint({ area, exerciseCategory }) {
  const areaHints = HINTS[area];
  if (!areaHints) return null;
  const hint = areaHints[exerciseCategory] || Object.values(areaHints)[0];
  if (!hint) return null;

  return (
    <div className="mt-3 p-3 bg-muted/60 rounded-lg border border-border flex items-center gap-3">
      <div className="flex-shrink-0">{hint.svg}</div>
      <p className="text-[11px] text-muted-foreground leading-snug">{hint.label}</p>
    </div>
  );
}