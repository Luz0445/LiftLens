import { AlertTriangle, ShieldAlert, Shield } from "lucide-react";
import { motion } from "framer-motion";
import FormCorrectionHint from "./FormCorrectionHint";

export default function InjuryRiskCard({ risks = [] }) {
  if (!risks.length) {
    return (
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Shield className="w-4 h-4 text-primary" />
          </div>
          <h3 className="font-heading font-semibold text-foreground">Injury Risk</h3>
        </div>
        <p className="text-sm text-primary">No injury risk patterns detected. Great form!</p>
      </div>
    );
  }

  const getSeverityStyles = (severity) => {
    switch (severity) {
      case "high": return { bg: "bg-destructive/10 border-destructive/20", text: "text-destructive", icon: ShieldAlert };
      case "moderate": return { bg: "bg-accent/10 border-accent/20", text: "text-accent", icon: AlertTriangle };
      default: return { bg: "bg-muted border-border", text: "text-muted-foreground", icon: Shield };
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg bg-destructive/10 flex items-center justify-center">
          <AlertTriangle className="w-4 h-4 text-destructive" />
        </div>
        <h3 className="font-heading font-semibold text-foreground">Injury Risk Indicators</h3>
      </div>
      <p className="text-[11px] text-muted-foreground mb-4 italic">
        Movement patterns associated with increased injury risk. Not a diagnosis.
      </p>
      <div className="space-y-3">
        {risks.map((risk, i) => {
          const styles = getSeverityStyles(risk.severity);
          const Icon = styles.icon;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`p-3 rounded-lg border ${styles.bg}`}
            >
              <div className="flex items-center gap-2 mb-1">
                <Icon className={`w-3.5 h-3.5 ${styles.text}`} />
                <span className={`text-sm font-medium ${styles.text}`}>{risk.area}</span>
                <span className={`text-[10px] uppercase tracking-wider ml-auto ${styles.text}`}>{risk.severity}</span>
              </div>
              <p className="text-xs text-muted-foreground">{risk.description}</p>
              {risk.exerciseCategory && (
                <FormCorrectionHint area={risk.area} exerciseCategory={risk.exerciseCategory} />
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}