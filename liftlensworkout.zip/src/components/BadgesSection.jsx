import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Trophy } from "lucide-react";
import moment from "moment";

export default function BadgesSection({ streakCount }) {
  const [badges, setBadges] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Badge.list("-created_date", 20).then((data) => {
      setBadges(data);
      setLoading(false);
    });
  }, []);

  if (loading) return null;

  return (
    <div className="space-y-4">
      {/* Streak bar */}
      <div className="bg-gradient-to-r from-orange-500/10 to-primary/10 border border-orange-500/20 rounded-xl p-4 flex items-center gap-4">
        <div className="text-3xl">🔥</div>
        <div className="flex-1">
          <p className="text-sm font-heading font-bold text-foreground">
            {streakCount > 0 ? `${streakCount}-Day Streak` : "No active streak"}
          </p>
          <p className="text-xs text-muted-foreground">
            {streakCount > 0 ? "Keep it up — train again tomorrow!" : "Complete a session to start your streak"}
          </p>
        </div>
        <div className="text-2xl font-heading font-black text-orange-400">{streakCount}</div>
      </div>

      {/* Badges */}
      {badges.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Trophy className="w-4 h-4 text-primary" />
            <h3 className="font-heading font-semibold text-foreground text-sm">Achievements</h3>
            <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{badges.length}</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {badges.map((badge, i) => (
              <motion.div
                key={badge.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                className="bg-card border border-border rounded-xl p-3 flex flex-col items-center text-center gap-1.5"
              >
                <span className="text-2xl">{badge.icon}</span>
                <p className="text-xs font-medium text-foreground leading-tight">{badge.title}</p>
                <p className="text-[10px] text-muted-foreground leading-tight">{badge.description}</p>
                <p className="text-[10px] text-muted-foreground/60">{moment(badge.created_date).fromNow()}</p>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}