import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

export default function BadgeToast({ badges, onDone }) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (index >= badges.length) {
      onDone();
      return;
    }
    const t = setTimeout(() => setIndex((i) => i + 1), 2800);
    return () => clearTimeout(t);
  }, [index, badges.length, onDone]);

  const current = badges[index];

  return (
    <div className="fixed inset-0 pointer-events-none flex items-end justify-center pb-24 z-50">
      <AnimatePresence mode="wait">
        {current && (
          <motion.div
            key={current.id}
            initial={{ opacity: 0, y: 40, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="bg-card border border-primary/40 shadow-2xl rounded-2xl px-6 py-4 flex items-center gap-4 max-w-sm w-full mx-4"
          >
            <span className="text-4xl">{current.icon}</span>
            <div>
              <p className="text-[10px] text-primary uppercase tracking-wider font-semibold mb-0.5">Badge Unlocked!</p>
              <p className="text-sm font-heading font-bold text-foreground">{current.title}</p>
              <p className="text-xs text-muted-foreground">{current.description}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}