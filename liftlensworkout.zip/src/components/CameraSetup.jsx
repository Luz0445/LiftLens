import { useEffect, useRef, useState } from "react";
import { Camera, ArrowLeft, Check, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const TIPS = [
  "Place camera 6–8 feet away from your lifting area",
  "Ensure your full body is visible in frame",
  "Good lighting helps improve tracking accuracy",
  "Position camera at hip height for the best angle",
  "Clear the area around you for safety",
];

export default function CameraSetup({ exercise, onReady, onBack }) {
  const videoRef = useRef(null);
  const [cameraError, setCameraError] = useState(null);
  const [cameraReady, setCameraReady] = useState(false);
  const [stream, setStream] = useState(null);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  async function startCamera() {
    setCameraError(null);
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play();
      }
      setStream(mediaStream);
      setCameraReady(true);
    } catch (err) {
      setCameraError(err.message || "Camera access denied. Please allow camera permissions.");
    }
  }

  function stopCamera() {
    if (stream) stream.getTracks().forEach((t) => t.stop());
  }

  function handleReady() {
    stopCamera();
    onReady();
  }

  return (
    <div className="space-y-6">
      <button onClick={() => { stopCamera(); onBack(); }} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="w-4 h-4" />
        Back to exercise selection
      </button>

      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        {/* Live Camera Preview */}
        <div className="aspect-video bg-black flex flex-col items-center justify-center relative">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className={`w-full h-full object-cover ${cameraReady ? "block" : "hidden"}`}
          />
          {!cameraReady && !cameraError && (
            <div className="flex flex-col items-center gap-3">
              <Camera className="w-12 h-12 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Starting camera...</p>
            </div>
          )}
          {cameraError && (
            <div className="flex flex-col items-center gap-3 p-6 text-center">
              <AlertCircle className="w-12 h-12 text-destructive" />
              <p className="text-sm text-destructive font-medium">Camera Error</p>
              <p className="text-xs text-muted-foreground">{cameraError}</p>
              <Button size="sm" onClick={startCamera} className="mt-2 bg-primary text-primary-foreground">
                Retry
              </Button>
            </div>
          )}
          {cameraReady && (
            <div className="absolute inset-4 border-2 border-dashed border-primary/40 rounded-xl pointer-events-none" />
          )}
        </div>

        <div className="p-6 space-y-4">
          <div>
            <h3 className="font-heading font-semibold text-foreground">
              Setting up for: <span className="text-primary">{exercise?.name}</span>
            </h3>
            <p className="text-sm text-muted-foreground mt-1">Position yourself so your full body is visible</p>
          </div>

          <div className="space-y-2.5">
            {TIPS.map((tip, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check className="w-3 h-3 text-primary" />
                </div>
                <p className="text-sm text-secondary-foreground">{tip}</p>
              </div>
            ))}
          </div>

          <Button
            onClick={handleReady}
            disabled={!cameraReady}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-heading font-semibold"
          >
            {cameraReady ? "I'm Ready — Start Recording" : "Waiting for camera..."}
          </Button>
        </div>
      </div>
    </div>
  );
}