import { motion } from "framer-motion";

export default function StatCard({ icon: Icon, label, value, subtext, trend, delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-card border border-border rounded-xl p-4"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon className="w-4 h-4 text-primary" />
        </div>
        {trend !== undefined && (
          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
            trend > 0 ? "bg-primary/10 text-primary" : trend < 0 ? "bg-destructive/10 text-destructive" : "bg-muted text-muted-foreground"
          }`}>
            {trend > 0 ? "+" : ""}{trend}%
          </span>
        )}
      </div>
      <p className="text-2xl font-heading font-bold text-foreground">{value}</p>
      <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
      {subtext && <p className="text-[11px] text-muted-foreground/70 mt-1">{subtext}</p>}
    </motion.div>
  );
}