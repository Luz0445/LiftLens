import { motion } from "framer-motion";

const JOINTS = {
  head: { x: 50, y: 8 },
  shoulder_left: { x: 35, y: 22 },
  shoulder_right: { x: 65, y: 22 },
  elbow_left: { x: 25, y: 38 },
  elbow_right: { x: 75, y: 38 },
  wrist_left: { x: 22, y: 50 },
  wrist_right: { x: 78, y: 50 },
  hip_left: { x: 40, y: 52 },
  hip_right: { x: 60, y: 52 },
  knee_left: { x: 38, y: 72 },
  knee_right: { x: 62, y: 72 },
  ankle_left: { x: 37, y: 92 },
  ankle_right: { x: 63, y: 92 },
};

const BONES = [
  ["head", "shoulder_left"], ["head", "shoulder_right"],
  ["shoulder_left", "shoulder_right"],
  ["shoulder_left", "elbow_left"], ["shoulder_right", "elbow_right"],
  ["elbow_left", "wrist_left"], ["elbow_right", "wrist_right"],
  ["shoulder_left", "hip_left"], ["shoulder_right", "hip_right"],
  ["hip_left", "hip_right"],
  ["hip_left", "knee_left"], ["hip_right", "knee_right"],
  ["knee_left", "ankle_left"], ["knee_right", "ankle_right"],
];

export default function SkeletonOverlay({ jointStatus = {}, className = "" }) {
  const getColor = (jointName) => {
    const status = jointStatus[jointName];
    if (status === "good") return "hsl(145 80% 50%)";
    if (status === "warning") return "hsl(40 95% 55%)";
    if (status === "bad") return "hsl(0 72% 55%)";
    return "hsl(210 20% 60%)";
  };

  return (
    <div className={`relative bg-card border border-border rounded-xl overflow-hidden ${className}`}>
      <div className="aspect-[3/4] relative">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
        <svg viewBox="0 0 100 100" className="w-full h-full">
          {BONES.map(([from, to], i) => (
            <motion.line
              key={i}
              x1={JOINTS[from].x}
              y1={JOINTS[from].y}
              x2={JOINTS[to].x}
              y2={JOINTS[to].y}
              stroke="hsl(210 20% 30%)"
              strokeWidth="0.8"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 0.8, delay: i * 0.03 }}
            />
          ))}
          {Object.entries(JOINTS).map(([name, pos], i) => (
            <motion.circle
              key={name}
              cx={pos.x}
              cy={pos.y}
              r="2"
              fill={getColor(name)}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.3, delay: 0.5 + i * 0.03 }}
            />
          ))}
        </svg>
        <div className="absolute bottom-3 left-3 right-3 flex gap-3">
          {[
            { color: "bg-primary", label: "Good" },
            { color: "bg-accent", label: "Warning" },
            { color: "bg-destructive", label: "Needs Work" },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-1.5">
              <div className={`w-2 h-2 rounded-full ${item.color}`} />
              <span className="text-[10px] text-muted-foreground">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}