import { motion } from "framer-motion";

export default function RepTimeline({ repData = [] }) {
  if (!repData.length) return null;

  const getStatusColor = (status) => {
    switch (status) {
      case "stable": return "bg-green-500";
      case "warning": return "bg-yellow-400";
      case "breakdown": return "bg-red-500";
      default: return "bg-muted-foreground";
    }
  };

  const getStatusBg = (status) => {
    switch (status) {
      case "stable": return "bg-green-500/10 border-green-500/20";
      case "warning": return "bg-yellow-400/10 border-yellow-400/20";
      case "breakdown": return "bg-red-500/10 border-red-500/20";
      default: return "bg-muted border-border";
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <h3 className="font-heading font-semibold text-foreground mb-4">Rep Timeline</h3>
      <div className="flex items-end gap-1.5">
        {repData.map((rep, i) => (
          <motion.div
            key={i}
            initial={{ height: 0 }}
            animate={{ height: `${rep.form_score}%` }}
            transition={{ duration: 0.5, delay: i * 0.05 }}
            className="flex-1 relative group"
          >
            <div
              className={`w-full rounded-t-md ${getStatusColor(rep.status)} min-h-[4px] transition-all`}
              style={{ height: `${rep.form_score}%`, minHeight: "8px", maxHeight: "80px" }}
            />
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className={`text-[10px] px-2 py-1 rounded-md border whitespace-nowrap ${getStatusBg(rep.status)}`}>
                Rep {rep.rep_number}: {rep.form_score}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
      <div className="flex justify-between mt-2">
        <span className="text-[10px] text-muted-foreground">Rep 1</span>
        <span className="text-[10px] text-muted-foreground">Rep {repData.length}</span>
      </div>
      <div className="flex flex-col gap-2 mt-4 pt-4 border-t border-border">
        <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wider mb-1">Form Key</p>
        <div className="flex items-start gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-green-500 mt-0.5 flex-shrink-0" />
          <div>
            <span className="text-[11px] font-medium text-green-400">Stable (≥75)</span>
            <p className="text-[10px] text-muted-foreground">Strong rep — joint angles are close to ideal, movement is controlled, and depth is consistent.</p>
          </div>
        </div>
        <div className="flex items-start gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-400 mt-0.5 flex-shrink-0" />
          <div>
            <span className="text-[11px] font-medium text-yellow-400">Warning (58–74)</span>
            <p className="text-[10px] text-muted-foreground">Minor deviations detected — joint angles drifting from target range, possible early fatigue or technique drift.</p>
          </div>
        </div>
        <div className="flex items-start gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500 mt-0.5 flex-shrink-0" />
          <div>
            <span className="text-[11px] font-medium text-red-400">Breakdown (&lt;58)</span>
            <p className="text-[10px] text-muted-foreground">Significant form breakdown — joints outside safe range, likely caused by fatigue or excessive load. Rest or reduce weight.</p>
          </div>
        </div>
      </div>
    </div>
  );
}