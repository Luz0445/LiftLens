import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Target, TrendingUp, TrendingDown, Minus } from "lucide-react";
import moment from "moment";

function computeGoalValue(goal, sessions) {
  const relevant = goal.exercise_category && goal.exercise_category !== "all"
    ? sessions.filter((s) => s.exercise_category === goal.exercise_category)
    : sessions;

  switch (goal.goal_type) {
    case "form_score":
      if (!relevant.length) return 0;
      return Math.round(relevant.slice(0, 5).reduce((s, r) => s + (r.form_score || 0), 0) / Math.min(relevant.length, 5));
    case "symmetry":
      if (!relevant.length) return 0;
      return Math.round(relevant.slice(0, 5).reduce((s, r) => s + (r.symmetry_score || 0), 0) / Math.min(relevant.length, 5));
    case "sessions_per_week": {
      const weekStart = moment().startOf("isoWeek");
      return sessions.filter((s) => moment(s.created_date).isAfter(weekStart)).length;
    }
    case "consistency":
      if (!relevant.length) return 0;
      return relevant.filter((s) => s.consistency_rating === "excellent" || s.consistency_rating === "good").length;
    case "depth":
      if (!relevant.length) return 0;
      return Math.round(relevant.slice(0, 3).reduce((s, r) => s + (r.depth_improvement || 0), 0) / Math.min(relevant.length, 3));
    default:
      return goal.current_value || 0;
  }
}

export default function GoalScorePanel() {
  const [goals, setGoals] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.UserGoal.filter({ status: "active" }, "-created_date", 10),
      base44.entities.WorkoutSession.list("-created_date", 50),
    ]).then(([g, s]) => {
      setGoals(g);
      setSessions(s);
      setLoading(false);
    });
  }, []);

  if (loading || !goals.length) return null;

  return (
    <div className="bg-muted/60 border border-border rounded-xl p-4">
      <div className="flex items-center gap-2 mb-3">
        <Target className="w-4 h-4 text-primary" />
        <p className="text-xs font-heading font-semibold text-foreground uppercase tracking-wider">Goal Progress</p>
      </div>
      <div className="space-y-3">
        {goals.map((g) => {
          const current = computeGoalValue(g, sessions);
          const pct = Math.min((current / g.target_value) * 100, 100);
          const prev = g.current_value || 0;
          const delta = current - prev;
          return (
            <div key={g.id}>
              <div className="flex justify-between items-center text-xs mb-1 gap-2">
                <span className="text-foreground font-medium truncate max-w-[55%]">{g.title}</span>
                <div className="flex items-center gap-1.5 shrink-0">
                  {delta > 0 ? (
                    <TrendingUp className="w-3 h-3 text-primary" />
                  ) : delta < 0 ? (
                    <TrendingDown className="w-3 h-3 text-destructive" />
                  ) : (
                    <Minus className="w-3 h-3 text-muted-foreground" />
                  )}
                  <span className="text-foreground font-semibold">{current}</span>
                  <span className="text-muted-foreground">/ {g.target_value}</span>
                  <span className={`text-[10px] font-bold ${pct >= 100 ? "text-primary" : "text-muted-foreground"}`}>
                    {Math.round(pct)}%
                  </span>
                </div>
              </div>
              <div className="h-1.5 bg-muted rounded-full">
                <div
                  className={`h-1.5 rounded-full transition-all ${pct >= 100 ? "bg-primary" : pct >= 60 ? "bg-primary/70" : "bg-primary/40"}`}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}